#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/HardStreak.hpp>
#include <Geode/modify/EffectGameObject.hpp>
#include <Geode/modify/GameObject.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <initializer_list>
#include <iterator>
#include <utility>
#include <unordered_set>
#include <vector>
#include <string>
#include <string_view>

#include "core/LevelScan.hpp"
#include "ui/FloatingPanelTouch.hpp"
#include "core/performance/AdaptiveScheduler.hpp"
#include "core/performance/LevelStrategyProfile.hpp"

using namespace geode::prelude;

namespace {
    using at::performance::AdaptiveScheduler;
    using at::performance::Preset;
    using at::performance::Settings;

    AdaptiveScheduler* g_performanceScheduler = nullptr;

    // 1=regular orb, 2=Spider Orb, 3=Dash Orb.
    struct LiveInteractionEvidence {
        int contactKind = 0;
        int activationKind = 0;
        float contactX = -100000.f;
        float activationX = -100000.f;
        void clear() noexcept { *this = LiveInteractionEvidence{}; }
    };
    LiveInteractionEvidence g_liveInteractionEvidence;

    Preset performancePreset() {
        const auto value = Mod::get()->getSettingValue<int64_t>("performance-preset");
        switch (value) {
            case 0: return Preset::UltraLow;
            case 1: return Preset::Low;
            case 2: return Preset::Balanced;
            case 3: return Preset::High;
            default: return Preset::Custom;
        }
    }

    Settings performanceSettings() {
        auto settings = Settings::forPreset(performancePreset());
        settings.adaptiveBudget = Mod::get()->getSettingValue<bool>("adaptive-budget");
        settings.deferScanDuringJump = Mod::get()->getSettingValue<bool>("jump-protection");
        settings.diagnostics = Mod::get()->getSettingValue<bool>("performance-diagnostics");
        settings.sanitize();
        return settings;
    }

    const char* performancePresetName(Preset preset) {
        switch (preset) {
            case Preset::UltraLow: return "ULTRA LOW";
            case Preset::Low: return "LOW";
            case Preset::Balanced: return "BALANCED";
            case Preset::High: return "HIGH";
            default: return "CUSTOM";
        }
    }

    bool autoPlayEnabled() {
        return Mod::get()->getSettingValue<bool>("auto-play");
    }

    bool trajectoryEnabled() {
        return Mod::get()->getSettingValue<bool>("show-trajectory");
    }

    bool uiEnabled() {
        return Mod::get()->getSettingValue<bool>("show-ui");
    }

    bool straightFlyEnabled() {
        return Mod::get()->getSettingValue<bool>("straight-fly");
    }

    bool waveRoomAwareEnabled() {
        return Mod::get()->getSettingValue<bool>("wave-room-aware");
    }

    bool waveDeepSearchEnabled() {
        return Mod::get()->getSettingValue<bool>("wave-deep-search");
    }

    bool debugLogEnabled() {
        return Mod::get()->getSettingValue<bool>("debug-log");
    }

    int trajectorySteps() {
        return static_cast<int>(Mod::get()->getSettingValue<int64_t>("trajectory-steps"));
    }

    int autoPlayLookahead() {
        return static_cast<int>(Mod::get()->getSettingValue<int64_t>("autoplay-lookahead"));
    }
}

#include "core/Simulation.hpp"

class $modify(AutoTrajPlayerObject, PlayerObject) {
    void update(float dt) {
        PlayerObject::update(dt);

        if (g_simulating) return;

        if (auto pl = PlayLayer::get(); pl && pl->m_player1 == this) {
            ++g_stepCounter;
            if (dt > 0.001f && dt < 2.f) {
                float warp = pl->m_gameState.m_timeWarp;
                if (!(warp > 0.f)) warp = 1;
                g_stepDt = dt / warp;
            }
        }
    }

    void incrementJumps() {
        // Jump counters belong to the real PlayLayer; do not increment them
        // while a predictive clone is being evaluated.
        if (g_simulating) return;
        if (g_performanceScheduler) g_performanceScheduler->notifyJump();
        PlayerObject::incrementJumps();
    }

    void ringJump(RingObject* ring, bool unk) {
        if (g_simulating && !isSimDummy(this)) return;
        if (g_simulating) {
            snapshotSimObject(ring);
            if (isSpiderOrb(ring)) recordSimSpiderOrbActivation(ring, g_simCurrentStep);
            else recordSimOrbActivation(ring, g_simCurrentStep);
        } else if (ring) {
            if (auto* pl = PlayLayer::get(); pl && pl->m_player1 == this) {
                g_liveInteractionEvidence.activationKind = isSpiderOrb(ring) ? 2 : 1;
                g_liveInteractionEvidence.activationX = getPositionX();
            }
        }
        PlayerObject::ringJump(ring, unk);
    }

    void playSpiderDashEffect(cocos2d::CCPoint from, cocos2d::CCPoint to) {
        if (g_simulating) {
            if (isSimDummy(this)) {
                const int playerIndex = this == g_simDummies[1] ? 1 : 0;
                auto* spiderOrb = g_simPendingSpiderOrb[playerIndex];
                if (spiderOrb) recordSimSpiderOrbActivation(spiderOrb, g_simCurrentStep);
                g_simPendingSpiderOrb[playerIndex] = nullptr;
            }
            return; // suppress only the clone's visual effect, not its activation evidence
        }
        if (auto* pl = PlayLayer::get(); pl && pl->m_player1 == this) {
            g_liveInteractionEvidence.activationKind = 2;
            g_liveInteractionEvidence.activationX = getPositionX();
        }
        PlayerObject::playSpiderDashEffect(from, to);
    }
};

class $modify(AutoTrajStreak, HardStreak) {
    void addPoint(cocos2d::CCPoint point) {
        if (g_simulating) return;
        HardStreak::addPoint(point);
    }
};

class $modify(AutoTrajEffectObject, EffectGameObject) {
    void triggerObject(GJBaseGameLayer* layer, int uniqueID, gd::vector<int> const* remapKeys) {
        if (g_simulating) return;
        EffectGameObject::triggerObject(layer, uniqueID, remapKeys);
    }
};

class $modify(AutoTrajGameObject, GameObject) {
    void playShineEffect() {
        if (g_simulating) return;
        GameObject::playShineEffect();
    }
};

class $modify(AutoTrajBaseLayer, GJBaseGameLayer) {
    bool canBeActivatedByPlayer(PlayerObject* player, EffectGameObject* object) {
        if (g_simulating) {
            if (!isSimDummy(player) || !isSimInteractable(object)) return false;
            snapshotSimObject(object);

            // A hidden clone is not one of PlayLayer's registered players, so
            // the base gate can reject an otherwise valid RingObject. Let the
            // standard orb interaction through for the clone, while respecting
            // the per-player activation flag in dual mode. The real game path
            // is untouched because this branch only runs during prediction.
            if (auto* ring = typeinfo_cast<RingObject*>(object)) {
                return ringCanActivateForDummy(ring, player, g_simInputDown);
            }
        }
        return GJBaseGameLayer::canBeActivatedByPlayer(player, object);
    }

    void playerTouchedRing(PlayerObject* player, RingObject* ring) {
        if (g_simulating) {
            if (!isSimDummy(player) || !ring) return;
            snapshotSimObject(ring);
        }
        GJBaseGameLayer::playerTouchedRing(player, ring);
    }

    void collisionCheckObjects(PlayerObject* player, gd::vector<GameObject*>* objects, int count, float dt) {
        if (g_simulating && isSimDummy(player) && objects) {
            gd::vector<GameObject*> filtered;
            filtered.reserve(count);
            auto playerRect = player->getObjectRect();
            for (int i = 0; i < count; ++i) {
                auto* object = objects->at(i);
                if (!object) continue;

                // Record actual hitbox contact even when Jump is released. This
                // gives the planner a real contact window to schedule around.
                if (auto* ring = typeinfo_cast<RingObject*>(object)) {
                    if (playerRect.intersectsRect(object->getObjectRect())) {
                        recordSimOrbContact(ring, g_simCurrentStep);
                        if (isSpiderOrb(ring))
                            recordSimSpiderOrbContact(ring, g_simCurrentStep, player);
                    }
                }

                // Teleport orbs depend on linked destination / trigger state,
                // which the clone intentionally does not mutate. Stop exactly
                // at their hitbox and let the next real frame re-sync.
                if (isTeleportOrb(object)) {
                    if (playerRect.intersectsRect(object->getObjectRect())) {
                        snapshotSimObject(object);
                        g_simPortal = true;
                        continue;
                    }
                }

                // Use actual hitbox intersection rather than a loose centre-point
                // radius. Supported portals are passed to the game's collision
                // code so the clone receives the real portal transition.
                if (isPortalId(object->m_objectID) &&
                    playerRect.intersectsRect(object->getObjectRect())) {
                    snapshotSimObject(object);
                    if (requiresPortalResync(object->m_objectID)) {
                        // Stop at the portal instead of pretending the old mode
                        // continues. The real player crosses it in the live tick;
                        // the next frame clones the newly transformed state.
                        g_simPortal = true;
                        continue;
                    }
                    filtered.push_back(object);
                    continue;
                }

                switch (object->m_objectType) {
                    case GameObjectType::Solid:
                    case GameObjectType::Hazard:
                    case GameObjectType::AnimatedHazard:
                    case GameObjectType::CollisionObject:
                    case GameObjectType::Slope:
                        filtered.push_back(object);
                        break;
                    default:
                        if (isSimInteractable(object)) {
                            snapshotSimObject(object);
                            filtered.push_back(object);
                        }
                        break;
                }
            }

            GJBaseGameLayer::collisionCheckObjects(
                player, &filtered, static_cast<int>(filtered.size()), dt
            );
            return;
        } else if (!g_simulating && objects) {
            if (auto* pl = PlayLayer::get(); pl && player == pl->m_player1) {
                const auto playerRect = player->getObjectRect();
                for (int i = 0; i < count; ++i) {
                    auto* object = objects->at(i);
                    auto* ring = typeinfo_cast<RingObject*>(object);
                    if (!ring || !playerRect.intersectsRect(object->getObjectRect())) continue;
                    g_liveInteractionEvidence.contactKind = isDashOrb(ring) ? 3 :
                        (isSpiderOrb(ring) ? 2 : 1);
                    g_liveInteractionEvidence.contactX = player->getPositionX();
                }
            }
        }

        GJBaseGameLayer::collisionCheckObjects(player, objects, count, dt);
    }
};

// Panel label helper: text plus green/red tint for ON/OFF state.
static void setStateLabel(cocos2d::CCLabelBMFont* label, const char* text, bool on) {
    if (!label) return;
    label->setString(text);
    label->setColor(on ? cocos2d::ccColor3B{120, 255, 150} : cocos2d::ccColor3B{255, 130, 130});
}

class $modify(AutoTrajPlayLayer, PlayLayer) {
    struct Fields {
        cocos2d::CCDrawNode* drawNode = nullptr;
        PlayerObject* dummy1 = nullptr;
        PlayerObject* dummy2 = nullptr;
        cocos2d::CCLayerColor* panel = nullptr;
        at::ui::FloatingPanelTouchLayer* panelTouch = nullptr;
        cocos2d::CCMenu* menu = nullptr;
        cocos2d::CCLabelBMFont* headerLabel = nullptr;
        cocos2d::CCLabelBMFont* scanLabel = nullptr;
        cocos2d::CCLabelBMFont* autoLabel = nullptr;
        cocos2d::CCLabelBMFont* trajLabel = nullptr;
        cocos2d::CCLabelBMFont* waveLabel = nullptr;
        cocos2d::CCLabelBMFont* deviceLabel = nullptr;
        cocos2d::CCLabelBMFont* planLabel = nullptr;
        cocos2d::CCLabelBMFont* adaptiveLabel = nullptr;
        cocos2d::CCLabelBMFont* metricsLabel = nullptr;
        cocos2d::CCLabelBMFont* statusLabel = nullptr;
        AdaptiveScheduler scheduler{performanceSettings()};
        at::LevelScan levelScan;
        int lastCheckpoint = -1;
        int lastScanPercent = -1;
        bool panelCollapsed = false;
        bool panelDragActive = false;
        bool panelDragMoved = false;
        cocos2d::CCPoint panelTouchStart = {0.f, 0.f};
        cocos2d::CCPoint panelPositionStart = {0.f, 0.f};
        bool botHolding = false;
        HoverState hover;
        bool waveTransitionActive = false;
        int waveStepsUntilTransition = 0;
        bool waveTransitionTarget = false;
        bool botTapActive = false;
        int botTapStepsRemaining = 0;
        bool orbTapScheduled = false;
        int orbTapStepsRemaining = 0;
        bool timedHoldActive = false;
        int timedHoldStepsRemaining = 0;
        bool timedHoldRobotMode = false;
        bool timedHoldDashMode = false;
        bool timedHoldDashStarted = false;
        bool dashHoldScheduled = false;
        int dashHoldStepsRemaining = 0;
        int dashHoldDurationSteps = 0;
        int timedHoldDashWaitStepsRemaining = 0;
        // Per-level planning learner; separate from the device frame budget.
        at::performance::LevelStrategyProfile levelStrategyProfile;
        std::string levelStrategyKey;
        Preset activeStrategyPreset = Preset::Low;
        int bestAttemptProgress = 0;
        bool deathLearningRecorded = false;
        bool lastObservedDashActive = false;
        bool lastPredictionSafe = false;
        bool lastPredictionMismatch = false;
        int lastDecisionAction = -1;
        int lastDecisionSurvived = 0;
        int lastDecisionHorizon = 0;
        float lastDecisionX = 0.f;
        float lastDecisionY = 0.f;
        bool loggedSetup = false;
        int logFrame = 0;
        int performanceLogFrame = 0;
        int lastLoggedAction = -1;
        bool lastAuto = false;
        bool lastTraj = true;
        bool lastUi = true;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) {
            return false;
        }

        m_fields->scheduler.setSettings(performanceSettings());
        this->loadLevelStrategy(level);
        g_liveInteractionEvidence.clear();
        m_fields->lastObservedDashActive = false;
        g_performanceScheduler = &m_fields->scheduler;

        if (m_objectLayer) {
            auto* draw = cocos2d::CCDrawNode::create();
            draw->setID("autotraj-draw-node"_spr);
            m_objectLayer->addChild(draw, 1000);
            m_fields->drawNode = draw;
        }

        m_fields->dummy1 = PlayerObject::create(1, 1, this, this, true);
        if (m_fields->dummy1 && m_objectLayer) {
            m_fields->dummy1->setVisible(false);
            m_fields->dummy1->setID("autotraj-dummy-1"_spr);
            m_fields->dummy1->retain();
            m_objectLayer->addChild(m_fields->dummy1, 999);
        } else {
            m_fields->dummy1 = nullptr;
        }

        // Second hidden player for dual mode.
        m_fields->dummy2 = PlayerObject::create(1, 1, this, this, false);
        if (m_fields->dummy2 && m_objectLayer) {
            m_fields->dummy2->setVisible(false);
            m_fields->dummy2->setID("autotraj-dummy-2"_spr);
            m_fields->dummy2->retain();
            m_objectLayer->addChild(m_fields->dummy2, 999);
        } else {
            m_fields->dummy2 = nullptr;
        }

        this->scanLevel();
        this->setupFloatingPanel();
        m_fields->hover = HoverState{};
        m_fields->botHolding = false;
        m_fields->botTapActive = false;
        m_fields->botTapStepsRemaining = 0;
        m_fields->orbTapScheduled = false;
        m_fields->orbTapStepsRemaining = 0;
        m_fields->timedHoldActive = false;
        m_fields->timedHoldStepsRemaining = 0;
        m_fields->timedHoldRobotMode = false;
        m_fields->timedHoldDashMode = false;
        m_fields->timedHoldDashStarted = false;
        m_fields->timedHoldDashWaitStepsRemaining = 0;
        m_fields->loggedSetup = false;
        g_warnedStepZero = false;

        return true;
    }

    void scanLevel() {
        std::vector<at::ObjectRecord> records;
        records.reserve(m_objects ? m_objects->count() : 0);
        if (m_objects) {
            for (unsigned i = 0; i < m_objects->count(); ++i) {
                auto* object = static_cast<GameObject*>(m_objects->objectAtIndex(i));
                if (!object) continue;
                at::ObjectClass category = at::ObjectClass::Other;
                if (typeinfo_cast<RingObject*>(object)) {
                    category = at::ObjectClass::Orb;
                } else {
                    switch (object->m_objectType) {
                        case GameObjectType::Hazard:
                        case GameObjectType::AnimatedHazard:
                        case GameObjectType::CollisionObject:
                        case GameObjectType::Slope:
                            category = at::ObjectClass::Hazard;
                            break;
                        case GameObjectType::YellowJumpPad:
                        case GameObjectType::PinkJumpPad:
                        case GameObjectType::RedJumpPad:
                        case GameObjectType::GravityPad:
                        case GameObjectType::SpiderPad:
                            category = at::ObjectClass::Pad;
                            break;
                        default:
                            if (isPortalId(object->m_objectID)) category = at::ObjectClass::Portal;
                            break;
                    }
                }
                records.push_back({object->getPositionX(), object->m_objectID, category});
            }
        }
        m_fields->levelScan.build(std::move(records), m_player1 ? m_player1->getPositionX() : 0.f);
        m_fields->lastCheckpoint = -1;
        m_fields->lastScanPercent = -1;
        log::info("[AT] level scan: {} objects, x={:.1f}..{:.1f}",
            m_fields->levelScan.objectCount(), m_fields->levelScan.minX(),
            m_fields->levelScan.maxX());
    }

    // Rewrites every panel label from the current settings (single source of truth).
    void refreshPanelLabels() {
        const bool autoOn = autoPlayEnabled();
        const bool trajOn = trajectoryEnabled();
        const bool waveOn = waveRoomAwareEnabled();
        const bool adaptiveOn = Mod::get()->getSettingValue<bool>("adaptive-budget");
        const char* preset = performancePresetName(performancePreset());
        setStateLabel(m_fields->autoLabel, autoOn ? "AUTO PLAY: ON" : "AUTO PLAY: OFF", autoOn);
        setStateLabel(m_fields->trajLabel, trajOn ? "TRAJECTORY: ON" : "TRAJECTORY: OFF", trajOn);
        setStateLabel(m_fields->waveLabel, waveOn ? "WAVE ASSIST: ON" : "WAVE ASSIST: OFF", waveOn);
        setStateLabel(m_fields->adaptiveLabel, adaptiveOn ? "AUTO-SAVE FPS: ON" : "AUTO-SAVE FPS: OFF", adaptiveOn);
        if (m_fields->deviceLabel) {
            m_fields->deviceLabel->setString(fmt::format("DEVICE: {}  >", preset).c_str());
        }
        if (m_fields->planLabel) {
            m_fields->planLabel->setString(fmt::format(
                "PLAN: {}  >", performancePresetName(m_fields->activeStrategyPreset)
            ).c_str());
        }
        if (m_fields->statusLabel) {
            m_fields->statusLabel->setString(fmt::format(
                "Auto {} | Path {} | Plan {}", autoOn ? "ON" : "OFF", trajOn ? "ON" : "OFF",
                performancePresetName(m_fields->activeStrategyPreset)
            ).c_str());
        }
    }

    void savePanelState() {
        if (!m_fields->panel) return;
        auto pos = m_fields->panel->getPosition();
        Mod::get()->setSavedValue<float>("panel-x", pos.x);
        Mod::get()->setSavedValue<float>("panel-y", pos.y);
        Mod::get()->setSavedValue<bool>("panel-collapsed", m_fields->panelCollapsed);
    }

    // Keeps the whole panel on screen (also after rotating / different resolution).
    void clampPanelToScreen() {
        if (!m_fields->panel) return;
        auto size = cocos2d::CCDirector::sharedDirector()->getWinSize();
        const float height = m_fields->panelCollapsed ? at::ui::kPanelCollapsedHeight : at::ui::kPanelExpandedHeight;
        auto pos = m_fields->panel->getPosition();
        pos.x = std::clamp(pos.x, 0.f, std::max(0.f, size.width - at::ui::kPanelWidth));
        pos.y = std::clamp(pos.y, 0.f, std::max(0.f, size.height - height));
        m_fields->panel->setPosition(pos);
    }

    void updatePanelLayout() {
        if (!m_fields->panel) return;
        const float height = m_fields->panelCollapsed ? at::ui::kPanelCollapsedHeight : at::ui::kPanelExpandedHeight;
        m_fields->panel->setContentSize({at::ui::kPanelWidth, height});
        const float cx = at::ui::kPanelWidth * 0.5f;
        if (m_fields->headerLabel) {
            // Header is also the drag handle; collapsed state shows a compact status line below it.
            m_fields->headerLabel->setPosition({cx, height - 13.f});
            m_fields->headerLabel->setString(
                m_fields->panelCollapsed ? "AUTO TRAJECTORY  [+]" : "AUTO TRAJECTORY  [-]"
            );
        }
        if (m_fields->statusLabel) {
            m_fields->statusLabel->setVisible(m_fields->panelCollapsed);
            m_fields->statusLabel->setPosition({cx, 8.f});
        }
        if (m_fields->scanLabel) {
            m_fields->scanLabel->setVisible(!m_fields->panelCollapsed);
            m_fields->scanLabel->setPosition({cx, 126.f});
        }
        if (m_fields->metricsLabel) {
            m_fields->metricsLabel->setVisible(!m_fields->panelCollapsed);
            m_fields->metricsLabel->setPosition({cx, 108.f});
        }
        if (m_fields->menu) m_fields->menu->setVisible(!m_fields->panelCollapsed);
        this->clampPanelToScreen();
        this->savePanelState();
    }

    void setupFloatingPanel() {
        auto panel = cocos2d::CCLayerColor::create(
            cocos2d::ccColor4B{13, 18, 26, 232}, at::ui::kPanelWidth, at::ui::kPanelExpandedHeight
        );
        if (!panel) return;
        panel->setAnchorPoint({0.f, 0.f});
        panel->setID("autotraj-floating-panel"_spr);
        panel->setPosition({
            Mod::get()->getSavedValue<float>("panel-x", 112.f),
            Mod::get()->getSavedValue<float>("panel-y", 105.f)
        });
        m_fields->panelCollapsed = Mod::get()->getSavedValue<bool>("panel-collapsed", false);
        this->addChild(panel, 1001);
        m_fields->panel = panel;

        auto header = cocos2d::CCLabelBMFont::create("AUTO TRAJECTORY  [-]", "bigFont.fnt");
        header->setScale(0.38f);
        header->setPosition({at::ui::kPanelWidth * 0.5f, 143.f});
        panel->addChild(header, 2);
        m_fields->headerLabel = header;

        auto status = cocos2d::CCLabelBMFont::create("", "bigFont.fnt");
        status->setScale(0.27f);
        status->setPosition({at::ui::kPanelWidth * 0.5f, 8.f});
        panel->addChild(status, 2);
        m_fields->statusLabel = status;

        auto scan = cocos2d::CCLabelBMFont::create("ROUTE SCAN: READY", "bigFont.fnt");
        scan->setScale(0.32f);
        scan->setPosition({at::ui::kPanelWidth * 0.5f, 126.f});
        panel->addChild(scan, 2);
        m_fields->scanLabel = scan;

        auto metrics = cocos2d::CCLabelBMFont::create("FPS --", "bigFont.fnt");
        metrics->setScale(0.27f);
        metrics->setPosition({at::ui::kPanelWidth * 0.5f, 108.f});
        panel->addChild(metrics, 2);
        m_fields->metricsLabel = metrics;

        auto autoLabel = cocos2d::CCLabelBMFont::create("AUTO PLAY: OFF", "bigFont.fnt");
        autoLabel->setScale(0.45f);
        auto autoItem = cocos2d::CCMenuItemLabel::create(
            autoLabel, this, menu_selector(AutoTrajPlayLayer::onToggleAutoPlay)
        );
        auto trajLabel = cocos2d::CCLabelBMFont::create("TRAJECTORY: ON", "bigFont.fnt");
        trajLabel->setScale(0.45f);
        auto trajItem = cocos2d::CCMenuItemLabel::create(
            trajLabel, this, menu_selector(AutoTrajPlayLayer::onToggleTrajectory)
        );
        auto waveLabel = cocos2d::CCLabelBMFont::create("WAVE PLAN: OFF", "bigFont.fnt");
        waveLabel->setScale(0.45f);
        auto waveItem = cocos2d::CCMenuItemLabel::create(
            waveLabel, this, menu_selector(AutoTrajPlayLayer::onToggleWavePlanner)
        );
        auto deviceLabel = cocos2d::CCLabelBMFont::create("DEVICE: LOW  >", "bigFont.fnt");
        deviceLabel->setScale(0.43f);
        auto deviceItem = cocos2d::CCMenuItemLabel::create(
            deviceLabel, this, menu_selector(AutoTrajPlayLayer::onCyclePerformancePreset)
        );
        auto planLabel = cocos2d::CCLabelBMFont::create("PLAN: LOW  >", "bigFont.fnt");
        planLabel->setScale(0.43f);
        auto planItem = cocos2d::CCMenuItemLabel::create(
            planLabel, this, menu_selector(AutoTrajPlayLayer::onCycleLevelPlan)
        );
        auto adaptiveLabel = cocos2d::CCLabelBMFont::create("ADAPTIVE BUDGET: ON", "bigFont.fnt");
        adaptiveLabel->setScale(0.43f);
        auto adaptiveItem = cocos2d::CCMenuItemLabel::create(
            adaptiveLabel, this, menu_selector(AutoTrajPlayLayer::onToggleAdaptiveBudget)
        );
        auto menu = cocos2d::CCMenu::create(
            autoItem, trajItem, waveItem, deviceItem, planItem, adaptiveItem, nullptr
        );
        menu->alignItemsVerticallyWithPadding(3.f);
        menu->setPosition({at::ui::kPanelWidth * 0.5f, 53.f});
        menu->setScale(0.74f);
        menu->setID("autotraj-menu"_spr);
        panel->addChild(menu, 2);

        m_fields->menu = menu;
        m_fields->autoLabel = autoLabel;
        m_fields->trajLabel = trajLabel;
        m_fields->waveLabel = waveLabel;
        m_fields->deviceLabel = deviceLabel;
        m_fields->planLabel = planLabel;
        m_fields->adaptiveLabel = adaptiveLabel;
        m_fields->lastAuto = autoPlayEnabled();
        m_fields->lastTraj = trajectoryEnabled();
        m_fields->lastUi = uiEnabled();
        this->refreshPanelLabels();
        panel->setVisible(m_fields->lastUi);
        this->updatePanelLayout();

        // The touch delegate only captures the header; menu buttons and the
        // rest of the game keep their regular touch handling.
        auto touchLayer = at::ui::FloatingPanelTouchLayer::create(
            this, panel, &m_fields->panelCollapsed,
            [this]() { this->updatePanelLayout(); }
        );
        if (touchLayer) {
            touchLayer->setID("autotraj-panel-touch"_spr);
            touchLayer->setOnDragEnd([this]() { this->savePanelState(); });
            this->addChild(touchLayer, 1002);
            m_fields->panelTouch = touchLayer;
        }
    }

    void onToggleAutoPlay(CCObject*) {
        bool value = !autoPlayEnabled();
        Mod::get()->setSettingValue<bool>("auto-play", value);
    }

    void onToggleTrajectory(CCObject*) {
        bool value = !trajectoryEnabled();
        Mod::get()->setSettingValue<bool>("show-trajectory", value);
    }

    void onCyclePerformancePreset(CCObject*) {
        auto value = Mod::get()->getSettingValue<int64_t>("performance-preset");
        value = (value + 1) % 4;
        Mod::get()->setSettingValue<int64_t>("performance-preset", value);
        m_fields->scheduler.setSettings(performanceSettings());
        this->refreshPanelLabels();
    }

    void onCycleLevelPlan(CCObject*) {
        const int nextIndex = (at::performance::strategyPresetIndex(m_fields->activeStrategyPreset) + 1) %
            static_cast<int>(at::performance::kStrategyPresetCount);
        m_fields->activeStrategyPreset = at::performance::strategyPresetFromIndex(nextIndex);

        // The current level's chosen plan is saved separately from Device Budget.
        if (!m_fields->levelStrategyKey.empty()) {
            const auto key = fmt::format("{}-manual-plan", m_fields->levelStrategyKey);
            Mod::get()->setSavedValue<int64_t>(key, nextIndex);
        }
        log::info("[AT PLAN] manual selection level={} plan={}",
            m_fields->levelStrategyKey, performancePresetName(m_fields->activeStrategyPreset));
        this->refreshPanelLabels();
    }

    void onToggleAdaptiveBudget(CCObject*) {
        const bool value = !Mod::get()->getSettingValue<bool>("adaptive-budget");
        Mod::get()->setSettingValue<bool>("adaptive-budget", value);
        m_fields->scheduler.setSettings(performanceSettings());
        this->refreshPanelLabels();
    }

    void onToggleWavePlanner(CCObject*) {
        bool value = !waveRoomAwareEnabled();
        Mod::get()->setSettingValue<bool>("wave-room-aware", value);
        this->cancelWaveTransition();
        this->refreshPanelLabels();
    }

    void releaseBot() {
        if (m_fields->botHolding && m_player1) {
            this->handleButton(false, 1, true);
        }
        m_fields->botHolding = false;
    }

    void pressBot() {
        if (!m_fields->botHolding && m_player1) {
            this->handleButton(true, 1, true);
            m_fields->botHolding = true;
        }
    }

    void cancelTap() {
        m_fields->botTapActive = false;
        m_fields->botTapStepsRemaining = 0;
    }

    void cancelOrbTapSchedule() {
        m_fields->orbTapScheduled = false;
        m_fields->orbTapStepsRemaining = 0;
        // All pending orb interactions are mutually exclusive.
        m_fields->dashHoldScheduled = false;
        m_fields->dashHoldStepsRemaining = 0;
        m_fields->dashHoldDurationSteps = 0;
    }

    void cancelWaveTransition() {
        m_fields->waveTransitionActive = false;
        m_fields->waveStepsUntilTransition = 0;
        m_fields->waveTransitionTarget = false;
    }

    void cancelTimedHold() {
        m_fields->timedHoldActive = false;
        m_fields->timedHoldStepsRemaining = 0;
        m_fields->timedHoldRobotMode = false;
        m_fields->timedHoldDashMode = false;
        m_fields->timedHoldDashStarted = false;
        m_fields->timedHoldDashWaitStepsRemaining = 0;
    }

    static std::string makeLevelStrategyKey(GJGameLevel* level) {
        if (!level) return "level-unknown";
        if (level->m_levelID != 0) return fmt::format("level-{}", level->m_levelID);
        // Local/editor levels can have ID 0. A stable FNV-1a hash of the name
        // keeps their profile separate without storing level contents.
        const char* name = level->m_levelName.c_str();
        std::uint64_t hash = 1469598103934665603ull;
        if (name) {
            for (auto p = reinterpret_cast<unsigned char const*>(name); *p; ++p) {
                hash ^= *p;
                hash *= 1099511628211ull;
            }
        }
        return fmt::format("level-local-{:016x}", hash);
    }

    Preset levelStrategyFallback() const {
        const auto value = Mod::get()->getSettingValue<int64_t>("level-strategy-default");
        return at::performance::strategyPresetFromIndex(static_cast<int>(value));
    }

    void loadLevelStrategy(GJGameLevel* level) {
        m_fields->levelStrategyKey = makeLevelStrategyKey(level);
        for (int i = 0; i < static_cast<int>(at::performance::kStrategyPresetCount); ++i) {
            auto key = fmt::format("{}-{}", m_fields->levelStrategyKey, i);
            m_fields->levelStrategyProfile.load(
                i, Mod::get()->getSavedValue<int64_t>(key, 0)
            );
        }
        const auto manualKey = fmt::format("{}-manual-plan", m_fields->levelStrategyKey);
        const auto savedPlan = Mod::get()->getSavedValue<int64_t>(manualKey, -1);
        const bool hasManualPlan = savedPlan >= 0 &&
            savedPlan < static_cast<int64_t>(at::performance::kStrategyPresetCount);
        m_fields->activeStrategyPreset = hasManualPlan
            ? at::performance::strategyPresetFromIndex(static_cast<int>(savedPlan))
            : levelStrategyFallback();
        m_fields->bestAttemptProgress = 0;
        m_fields->deathLearningRecorded = false;
        log::info("[AT PLAN] level={} loaded-plan={} source={}",
            m_fields->levelStrategyKey, performancePresetName(m_fields->activeStrategyPreset),
            hasManualPlan ? "manual-save" : "default-setting");
    }

    void saveLevelStrategy() {
        for (int i = 0; i < static_cast<int>(at::performance::kStrategyPresetCount); ++i) {
            auto key = fmt::format("{}-{}", m_fields->levelStrategyKey, i);
            Mod::get()->setSavedValue<int64_t>(key, m_fields->levelStrategyProfile.save(i));
        }
    }

    void recordDeathLearning(GameObject* deathObject = nullptr) {
        if (m_fields->deathLearningRecorded || !m_player1 || !m_player1->m_isDead ||
            !autoPlayEnabled() || m_fields->levelStrategyKey.empty()) return;

        int progress = m_fields->bestAttemptProgress;
        if (m_fields->levelScan.valid()) {
            progress = std::max(progress,
                m_fields->levelScan.progressPercent(m_player1->getPositionX()));
        }
        const float deathX = m_player1->getPositionX();
        const bool recentContact = g_liveInteractionEvidence.contactKind != 0 &&
            deathX >= g_liveInteractionEvidence.contactX - 20.f &&
            deathX - g_liveInteractionEvidence.contactX <= 180.f;
        const bool activatedAfterContact = g_liveInteractionEvidence.activationKind ==
                g_liveInteractionEvidence.contactKind &&
            g_liveInteractionEvidence.activationX >= g_liveInteractionEvidence.contactX - 20.f &&
            g_liveInteractionEvidence.activationX <= deathX + 20.f;
        const bool missedInteraction = recentContact && !activatedAfterContact &&
            (g_liveInteractionEvidence.contactKind == 2 || g_liveInteractionEvidence.contactKind == 3 ||
             g_liveInteractionEvidence.contactKind == 1);
        const bool mismatch = m_fields->lastPredictionSafe;
        const auto preset = m_fields->activeStrategyPreset;
        const bool learningEnabled = Mod::get()->getSettingValue<bool>("level-adaptive-strategy");
        if (learningEnabled) {
            m_fields->levelStrategyProfile.record(preset, progress, mismatch);
            this->saveLevelStrategy();
        }
        // This latch prevents duplicate death samples. It intentionally does
        // not trigger a preset change; the active plan stays user-selected.
        m_fields->deathLearningRecorded = true;

        const char* diagnosis = "UNCLASSIFIED_DEATH";
        const char* recommendation = "Keep debug log enabled; compare the next attempt at the same section without changing the selected Plan.";
        if (missedInteraction) {
            switch (g_liveInteractionEvidence.contactKind) {
                case 2:
                    diagnosis = "SPIDER_ORB_NOT_CONFIRMED";
                    recommendation = "Re-sync the spider teleport event; verify the target-side collision before planning the next jump.";
                    break;
                case 3:
                    diagnosis = "DASH_ORB_NOT_CONFIRMED";
                    recommendation = "Hold until m_isDashing is confirmed; start the duration timer only after activation.";
                    break;
                default:
                    diagnosis = "ORB_NOT_CONFIRMED";
                    recommendation = "Re-test a frame-aligned tap window and require a confirmed activation, not overlap alone.";
                    break;
            }
        } else if (deathObject) {
            const auto type = deathObject->m_objectType;
            diagnosis = (type == GameObjectType::Hazard || type == GameObjectType::AnimatedHazard)
                ? "HAZARD_COLLISION" : "OBJECT_COLLISION";
            recommendation = "Use the logged collision object ID/type/position to inspect its hitbox and nearby triggers; compare the next strategy at this exact section.";
        } else if (mismatch) {
            diagnosis = "LIVE_SIM_DIVERGENCE_CANDIDATE";
            recommendation = "The last no-input forecast looked safe but the live attempt died; inspect the collision object, moving triggers and input timing before changing the profile.";
        } else if (m_fields->lastDecisionSurvived < m_fields->lastDecisionHorizon) {
            diagnosis = "NO_SAFE_ROUTE_FOUND";
            recommendation = "Manually select a different Plan in the panel, then compare progress at this section.";
        }
        int causeCode = 0;
        if (std::string_view(diagnosis) == "SPIDER_ORB_NOT_CONFIRMED") causeCode = 1;
        else if (std::string_view(diagnosis) == "DASH_ORB_NOT_CONFIRMED") causeCode = 2;
        else if (std::string_view(diagnosis) == "ORB_NOT_CONFIRMED") causeCode = 3;
        else if (std::string_view(diagnosis) == "HAZARD_COLLISION") causeCode = 4;
        else if (std::string_view(diagnosis) == "OBJECT_COLLISION") causeCode = 5;
        else if (std::string_view(diagnosis) == "LIVE_SIM_DIVERGENCE_CANDIDATE") causeCode = 6;
        else if (std::string_view(diagnosis) == "NO_SAFE_ROUTE_FOUND") causeCode = 7;
        auto causeKey = fmt::format("{}-death-cause-{}", m_fields->levelStrategyKey, causeCode);
        const auto previousCauseCount = Mod::get()->getSavedValue<int64_t>(causeKey, 0);
        const auto causeCount = std::min<int64_t>(999999, previousCauseCount + 1);
        Mod::get()->setSavedValue<int64_t>(causeKey, causeCount);

        const int deathObjectId = deathObject ? deathObject->m_objectID : -1;
        const int deathObjectType = deathObject ? static_cast<int>(deathObject->m_objectType) : -1;
        const float deathObjectX = deathObject ? deathObject->getPositionX() : -1.f;
        const float deathObjectY = deathObject ? deathObject->getPositionY() : -1.f;
        const auto recommended = m_fields->levelStrategyProfile.recommendation(levelStrategyFallback());
        log::warn("[AT LEARN] death level={} progress={} activePlan={} recommendation={} learning={} diagnosis={} action={} predicted={}/{} lastXY=({:.1f},{:.1f}) objectId={} objectType={} objectXY=({:.1f},{:.1f}) sameCauseCount={} contactKind={} contactX={:.1f} activationKind={} activationX={:.1f} advice=\"{}\"",
            m_fields->levelStrategyKey, progress, performancePresetName(preset),
            performancePresetName(recommended), learningEnabled ? "ON" : "OFF", diagnosis,
            m_fields->lastDecisionAction, m_fields->lastDecisionSurvived,
            m_fields->lastDecisionHorizon, m_fields->lastDecisionX, m_fields->lastDecisionY,
            deathObjectId, deathObjectType, deathObjectX, deathObjectY, causeCount,
            g_liveInteractionEvidence.contactKind, g_liveInteractionEvidence.contactX,
            g_liveInteractionEvidence.activationKind, g_liveInteractionEvidence.activationX,
            recommendation);
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) override {
        if (g_simulating && isSimDummy(player)) {
            g_simDead = true;
            return;
        }

        PlayLayer::destroyPlayer(player, object);
        if (player == m_player1) {
            this->recordDeathLearning(object);
            m_fields->botHolding = false;
            this->cancelTap();
            this->cancelOrbTapSchedule();
            this->cancelWaveTransition();
            this->cancelTimedHold();
        }
    }

    void resetLevel() override {
        PlayLayer::resetLevel();
        // Keep the same manually selected plan across retries. Death learning
        // updates statistics/recommendations only; it never rotates the plan.
        m_fields->deathLearningRecorded = false;
        m_fields->bestAttemptProgress = 0;
        m_fields->lastObservedDashActive = false;
        g_liveInteractionEvidence.clear();
        m_fields->lastPredictionSafe = false;
        m_fields->lastPredictionMismatch = false;
        m_fields->botHolding = false;
        this->cancelTap();
        this->cancelOrbTapSchedule();
        this->cancelWaveTransition();
        this->cancelTimedHold();
    }

    void playEndAnimationToPos(cocos2d::CCPoint pos) {
        if (g_simulating) return;
        PlayLayer::playEndAnimationToPos(pos);
    }

    void flipGravity(PlayerObject* player, bool flip, bool noEffects) {
        if (g_simulating && !isSimDummy(player)) return;
        PlayLayer::flipGravity(player, flip, noEffects);
    }

    void postUpdate(float dt) override {
        PlayLayer::postUpdate(dt);
        if (m_player1) {
            if (m_player1->m_isDashing && !m_fields->lastObservedDashActive) {
                g_liveInteractionEvidence.activationKind = 3;
                g_liveInteractionEvidence.activationX = m_player1->getPositionX();
            }
            m_fields->lastObservedDashActive = m_player1->m_isDashing;
        }
        this->recordDeathLearning();
        if (m_player1 && !m_player1->m_isDead && m_fields->levelScan.valid()) {
            m_fields->bestAttemptProgress = std::max(
                m_fields->bestAttemptProgress,
                m_fields->levelScan.progressPercent(m_player1->getPositionX())
            );
        }

        m_fields->scheduler.setSettings(performanceSettings());
        m_fields->scheduler.beginFrame(dt > 0.f ? dt * 1000.f : 0.f);
        const auto perfMetrics = m_fields->scheduler.metrics();
        if (Mod::get()->getSettingValue<bool>("performance-diagnostics") &&
            ++m_fields->performanceLogFrame % 120 == 0) {
            log::info("[AT PERF] deviceBudget={} levelStrategy={} avgFrame={:.2f}ms budget={}us deferred={} adaptiveCuts={} emergencyYields={} jumpGrace={}",
                performancePresetName(performancePreset()), performancePresetName(m_fields->activeStrategyPreset), perfMetrics.averageFrameMs,
                perfMetrics.currentBudgetUs, perfMetrics.deferredSlices,
                perfMetrics.adaptiveReductions, perfMetrics.emergencyYields,
                perfMetrics.jumpGraceActive);
        }
        if (m_fields->metricsLabel && m_fields->scheduler.mayRun(AdaptiveScheduler::WorkClass::UI)) {
            const double ms = perfMetrics.averageFrameMs;
            m_fields->metricsLabel->setString(fmt::format(
                "FPS {:.0f}{}", ms > 0.01 ? 1000.0 / ms : 0.0,
                perfMetrics.jumpGraceActive ? "  |  JUMP SAFE" : ""
            ).c_str());
        }

        if (g_stepCounter > 0) {
            g_frameSubsteps = std::clamp(g_stepCounter, 1, 16);
        }
        g_stepCounter = 0;

        const bool autoOn = autoPlayEnabled();
        const bool trajOn = trajectoryEnabled();
        const bool uiOn = uiEnabled();

        if (autoOn != m_fields->lastAuto) {
            this->refreshPanelLabels();
            m_fields->lastAuto = autoOn;
        }

        if (trajOn != m_fields->lastTraj) {
            this->refreshPanelLabels();
            if (m_fields->drawNode) {
                m_fields->drawNode->setVisible(trajOn);
            }
            m_fields->lastTraj = trajOn;
        }

        if (uiOn != m_fields->lastUi) {
            if (m_fields->panel) {
                m_fields->panel->setVisible(uiOn);
            }
            m_fields->lastUi = uiOn;
        }

        const bool drawDue = trajOn && m_fields->scheduler.mayRun(
            AdaptiveScheduler::WorkClass::TrajectoryReplan
        );
        if (m_fields->drawNode) {
            if (drawDue) m_fields->drawNode->clear();
            m_fields->drawNode->setVisible(trajOn);
        }

        if (!m_fields->loggedSetup) {
            m_fields->loggedSetup = true;
            log::info(
                "Auto Trajectory active: tick dt {:.4f}, preview {}, lookahead {}",
                g_stepDt, trajectorySteps(), autoPlayLookahead()
            );
        }

        if (!m_player1 || m_player1->m_isDead || !m_fields->dummy1) {
            this->releaseBot();
            this->cancelTap();
            this->cancelOrbTapSchedule();
            this->cancelWaveTransition();
            this->cancelTimedHold();
            return;
        }

        // Platformer levels are not supported (no fixed forward motion).
        if (m_player1->m_isPlatformer) {
            this->releaseBot();
            this->cancelTap();
            this->cancelOrbTapSchedule();
            this->cancelWaveTransition();
            this->cancelTimedHold();
            return;
        }

        if (!m_fields->levelScan.valid() && m_objects && m_objects->count() > 0) {
            this->scanLevel();
        }
        if (m_fields->levelScan.valid()) {
            const float playerX = m_player1->getPositionX();
            const int checkpoint = m_fields->levelScan.checkpointFor(playerX);
            const int percent = m_fields->levelScan.progressPercent(playerX);
            auto const* summary = m_fields->levelScan.checkpoint(checkpoint);
            if (percent != m_fields->lastScanPercent && m_fields->scanLabel) {
                m_fields->lastScanPercent = percent;
                auto scanText = fmt::format(
                    "ROUTE {:d}% | ZONE {:d}/4 | {} OBJECTS",
                    percent, checkpoint + 1, summary ? summary->objects : 0
                );
                m_fields->scanLabel->setString(scanText.c_str());
            }
            if (checkpoint != m_fields->lastCheckpoint) {
                m_fields->lastCheckpoint = checkpoint;
                if (summary) {
                    log::info(
                        "[AT] checkpoint {} ({}%): objects={} hazards={} orbs={} pads={} portals={}",
                        checkpoint + 1, checkpoint * 25, summary->objects,
                        summary->hazards, summary->orbs, summary->pads, summary->portals
                    );
                }
            }
        }

        // With Auto Play disabled, the overlay is the only reason to simulate.
        // Skip the whole predictive pass on throttled frames and during jump grace.
        if (!autoOn && !drawDue) return;

        float dtStep = g_stepDt;
        if (!(dtStep > 0.001f) || dtStep > 2.f) {
            dtStep = 0.25f;
        }

        // The overlay length is purely visual. The bot has its own lookahead,
        // so changing one never changes how the other behaves.
        // Planning depth is a level-specific strategy choice. Device Budget is
        // deliberately handled by AdaptiveScheduler and must not overwrite the
        // profile that the learner discovered for this level.
        const int presetHorizon = m_fields->activeStrategyPreset == Preset::UltraLow ? 72 :
            (m_fields->activeStrategyPreset == Preset::Low ? 120 :
            (m_fields->activeStrategyPreset == Preset::Balanced ? 200 : 320));
        int drawSteps = drawDue ? std::min(std::clamp(trajectorySteps(), 10, 400), presetHorizon) : 0;
        int botSteps = autoOn ? std::min(std::clamp(autoPlayLookahead(), 24, 480), presetHorizon) : 0;
        int horizon = std::max(drawSteps, botSteps);

        if (horizon <= 0) {
            this->releaseBot();
            this->cancelTap();
            this->cancelOrbTapSchedule();
            this->cancelWaveTransition();
            this->cancelTimedHold();
            return;
        }

        SimRig rig;
        rig.pl = this;
        rig.dummy = m_fields->dummy1;
        rig.source = m_player1;
        rig.dt = dtStep;
        rig.roomAwareWave = waveRoomAwareEnabled();
        // Deep search is intentionally disabled on low-end presets and during
        // the jump grace window to avoid candidate bursts near input events.
        rig.deepWaveSearch = waveDeepSearchEnabled() &&
            (m_fields->activeStrategyPreset == Preset::High) &&
            !perfMetrics.jumpGraceActive;
        if (m_gameState.m_isDualMode && m_player2 && m_fields->dummy2 && !m_player2->m_isDead) {
            rig.dummy2 = m_fields->dummy2;
            rig.source2 = m_player2;
        }

        bool timedHoldForced = false;
        bool timedHoldJustReleased = false;
        if (m_fields->timedHoldActive) {
            const bool modeChanged = m_fields->timedHoldRobotMode && !m_player1->m_isRobot;
            const bool dashBecameActive = m_fields->timedHoldDashMode &&
                !m_fields->timedHoldDashStarted && m_player1->m_isDashing;
            if (dashBecameActive) m_fields->timedHoldDashStarted = true;
            const bool dashEnded = m_fields->timedHoldDashMode &&
                m_fields->timedHoldDashStarted && !m_player1->m_isDashing;
            if (modeChanged || dashEnded) {
                this->cancelTimedHold();
                this->releaseBot();
                timedHoldJustReleased = true;
            } else if (m_fields->timedHoldDashMode && !m_fields->timedHoldDashStarted) {
                // Do not burn the dash duration while waiting for contact. A short
                // watchdog prevents a missed orb from leaving Jump held forever.
                m_fields->timedHoldDashWaitStepsRemaining -= std::max(1, g_frameSubsteps);
                if (m_fields->timedHoldDashWaitStepsRemaining <= 0) {
                    this->cancelTimedHold();
                    this->releaseBot();
                    timedHoldJustReleased = true;
                } else {
                    timedHoldForced = true;
                }
            } else if (dashBecameActive) {
                // Activation has just been observed. Start counting on the next
                // game update so the requested active-dash duration is not shortened.
                timedHoldForced = true;
            } else {
                m_fields->timedHoldStepsRemaining -= std::max(1, g_frameSubsteps);
                if (m_fields->timedHoldStepsRemaining <= 0) {
                    this->releaseBot();
                    this->cancelTimedHold();
                    timedHoldJustReleased = true;
                } else {
                    timedHoldForced = true;
                }
            }
        }

        auto* drawNode = drawSteps > 0 ? m_fields->drawNode : nullptr;

        // Green: press & hold now (overlay only).
        SimResult holdResult{};
        if (drawSteps > 0) {
            holdResult = runSimulation(
                rig, SimPlan::Hold, 0, -1, drawSteps, drawSteps,
                drawNode, cocos2d::ccColor4F{0.15f, 1.f, 0.35f, 1.f}
            );
        }

        // Red: release now. Shared with the bot's "is it dangerous?" check.
        SimResult idleResult = runSimulation(
            rig, SimPlan::Release, 0, -1, horizon, drawSteps,
            drawNode, cocos2d::ccColor4F{1.f, 0.3f, 0.3f, 1.f}
        );

        if (trajOn && holdResult.died && idleResult.died &&
            holdResult.survived == 0 && idleResult.survived == 0 && !g_warnedStepZero) {
            g_warnedStepZero = true;
            log::warn(
                "Auto Trajectory: simulation dies at step 0 near x={:.1f} y={:.1f}",
                m_player1->getPosition().x, m_player1->getPosition().y
            );
        }

        // Every Tap is a single-frame pulse. Release it at this frame boundary
        // and re-plan from the actual player state; do not hold indefinitely
        // while waiting for a landing or a takeoff that may never happen.
        if (m_fields->botTapActive &&
            advanceTapPulse(m_fields->botTapStepsRemaining, g_frameSubsteps)) {
            this->releaseBot();
            this->cancelTap();
        }

        bool orbTapForced = false;
        BotAction orbTapForcedAction = BotAction::Release;
        if (m_fields->orbTapScheduled) {
            const bool clickDue = advanceOrbTapSchedule(
                m_fields->orbTapStepsRemaining, g_frameSubsteps
            );
            if (clickDue) {
                this->cancelOrbTapSchedule();
                orbTapForced = true;
                orbTapForcedAction = BotAction::Tap;
            } else if (!orbTapScheduleStillReachable(
                idleResult, m_fields->orbTapStepsRemaining
            )) {
                // The predicted release path now dies before the scheduled click;
                // discard the stale timing and let the controller re-plan.
                this->cancelOrbTapSchedule();
            } else {
                orbTapForced = true;
                orbTapForcedAction = BotAction::Release;
            }
        }

        bool dashHoldForced = false;
        bool dashHoldDue = false;
        int dashHoldForcedSteps = 0;
        if (m_fields->dashHoldScheduled) {
            const bool due = advanceOrbTapSchedule(
                m_fields->dashHoldStepsRemaining, g_frameSubsteps
            );
            if (due) {
                dashHoldForced = true;
                dashHoldDue = true;
                dashHoldForcedSteps = m_fields->dashHoldDurationSteps;
                m_fields->dashHoldScheduled = false;
                m_fields->dashHoldStepsRemaining = 0;
                m_fields->dashHoldDurationSteps = 0;
            } else if (!orbTapScheduleStillReachable(
                idleResult, m_fields->dashHoldStepsRemaining
            )) {
                this->cancelOrbTapSchedule();
            } else {
                // Keep Jump released until the chosen frame; pressing early can
                // jump before a Dash Orb and invalidate the predicted approach.
                dashHoldForced = true;
            }
        }

        if (autoOn) {
            BotAction action = BotAction::Release;
            const bool scheduledWave = m_player1->m_isDart && rig.roomAwareWave;
            bool waveDidSwitch = false;
            if (!scheduledWave && m_fields->waveTransitionActive) {
                this->cancelWaveTransition();
            }
            int selectedTimedHoldSteps = 0;
            int selectedOrbTapDelaySteps = 0;
            int selectedDashHoldSteps = 0;
            int selectedDashHoldDelaySteps = 0;
            if (orbTapForced || dashHoldForced || timedHoldForced) m_fields->hover.active = false;
            if (orbTapForced) {
                action = orbTapForcedAction;
            } else if (dashHoldForced) {
                if (!dashHoldDue) {
                    action = BotAction::Release;
                } else if (dashHoldForcedSteps < 0) {
                    action = BotAction::Hold;
                } else {
                    action = BotAction::DashTimedHold;
                    selectedDashHoldSteps = dashHoldForcedSteps;
                }
            } else if (timedHoldForced) {
                action = BotAction::Hold;
            } else if (timedHoldJustReleased) {
                action = BotAction::Release;
            } else if (scheduledWave && m_fields->waveTransitionActive) {
                // Execute the first planned switch at a frame boundary. Recheck
                // the current straight segment; cancel the schedule if the live
                // state is no longer predicted to survive until that switch.
                m_fields->waveStepsUntilTransition -= std::max(1, g_frameSubsteps);
                if (m_fields->waveStepsUntilTransition <= 0) {
                    action = m_fields->waveTransitionTarget ? BotAction::Hold : BotAction::Release;
                    this->cancelWaveTransition();
                    waveDidSwitch = true;
                } else {
                    const int checkSteps = std::min(m_fields->waveStepsUntilTransition, botSteps);
                    SimResult currentPath = probe(
                        rig, m_fields->botHolding ? SimPlan::Hold : SimPlan::Release,
                        0, -1, checkSteps
                    );
                    if (currentPath.died && currentPath.survived < checkSteps) {
                        this->cancelWaveTransition();
                    } else {
                        action = m_fields->botHolding ? BotAction::Hold : BotAction::Release;
                    }
                }
            }

            if (!orbTapForced && !dashHoldForced && !timedHoldForced && !timedHoldJustReleased &&
                !waveDidSwitch && (!scheduledWave || !m_fields->waveTransitionActive)) {
                WavePlan selectedWavePlan;
                action = decideAutoPress(
                    rig, idleResult, botSteps, m_fields->botHolding,
                    scheduledWave ? &selectedWavePlan : nullptr,
                    &selectedTimedHoldSteps,
                    &selectedOrbTapDelaySteps,
                    straightFlyEnabled() ? &m_fields->hover : nullptr,
                    &selectedDashHoldSteps,
                    &selectedDashHoldDelaySteps
                );
                if (scheduledWave && selectedWavePlan.switchCount > 0) {
                    m_fields->waveTransitionActive = true;
                    m_fields->waveStepsUntilTransition = selectedWavePlan.switchSteps[0];
                    m_fields->waveTransitionTarget = !selectedWavePlan.startHolding;
                }
            }

            m_fields->lastDecisionAction = static_cast<int>(action);
            m_fields->lastDecisionSurvived = idleResult.survived;
            m_fields->lastDecisionHorizon = botSteps;
            m_fields->lastDecisionX = m_player1->getPositionX();
            m_fields->lastDecisionY = m_player1->getPositionY();
            m_fields->lastPredictionSafe = !idleResult.died || idleResult.survived >= botSteps;
            m_fields->lastPredictionMismatch = false;

            if (debugLogEnabled()) {
                ++m_fields->logFrame;
                const bool hazard = idleResult.died && idleResult.survived < botSteps;
                if (static_cast<int>(action) != m_fields->lastLoggedAction ||
                    (hazard && m_fields->logFrame % 15 == 0)) {
                    m_fields->lastLoggedAction = static_cast<int>(action);
                    log::info(
                        "[AT] f={} x={:.0f} y={:.0f} gnd={} up={} mode={} dual={} "
                        "idle(died={} surv={} orbContact={} orbFirst={} orbActivated={} spiderContact={} spiderActivated={} dashContact={} dashFirst={} dashActive={} dashActivated={}) "
                        "tapPulse={} tapLeft={} orbPlanDelay={} orbDelayLeft={} holdLeft={} action={}",
                        m_fields->logFrame, m_player1->getPositionX(), m_player1->getPositionY(),
                        m_player1->m_isOnGround, m_player1->m_isUpsideDown,
                        m_player1->m_isBall ? "ball" : (m_player1->m_isRobot ? "robot" :
                            (m_player1->m_isShip ? "ship" : (m_player1->m_isBird ? "ufo" :
                            (m_player1->m_isDart ? "wave" : (m_player1->m_isSwing ? "swing" :
                            (m_player1->m_isSpider ? "spider" : "cube")))))),
                        rig.dummy2 != nullptr, idleResult.died, idleResult.survived,
                        idleResult.orbContacts, idleResult.firstOrbContactStep,
                        idleResult.orbActivations, idleResult.spiderOrbContacts,
                        idleResult.spiderOrbActivations, idleResult.dashContacts,
                        idleResult.firstDashContactStep, idleResult.dashActiveAtEnd,
                        idleResult.dashActivations, m_fields->botTapActive,
                        m_fields->botTapStepsRemaining, selectedOrbTapDelaySteps,
                        m_fields->orbTapStepsRemaining,
                        m_fields->timedHoldStepsRemaining, static_cast<int>(action)
                    );
                }
            }

            switch (action) {
                case BotAction::Hold:
                    this->cancelTap();
                    this->cancelOrbTapSchedule();
                    if (!timedHoldForced) this->cancelTimedHold();
                    this->pressBot();
                    break;
                case BotAction::TimedHold:
                    this->cancelTap();
                    this->cancelOrbTapSchedule();
                    this->cancelTimedHold();
                    this->cancelWaveTransition();
                    if (requiresFreshPressEdge(action, m_fields->botHolding)) this->releaseBot();
                    this->pressBot();
                    m_fields->timedHoldActive = true;
                    m_fields->timedHoldStepsRemaining = std::max(
                        std::max(1, g_frameSubsteps), selectedTimedHoldSteps
                    );
                    m_fields->timedHoldRobotMode = m_player1->m_isRobot;
                    break;
                case BotAction::DashTimedHold:
                    this->cancelTap();
                    this->cancelOrbTapSchedule();
                    this->cancelTimedHold();
                    this->cancelWaveTransition();
                    if (!m_player1->m_isDashing && requiresFreshPressEdge(action, m_fields->botHolding))
                        this->releaseBot();
                    this->pressBot();
                    m_fields->timedHoldActive = true;
                    m_fields->timedHoldStepsRemaining = std::max(
                        std::max(1, g_frameSubsteps), selectedDashHoldSteps
                    );
                    m_fields->timedHoldRobotMode = false;
                    m_fields->timedHoldDashMode = true;
                    m_fields->timedHoldDashStarted = m_player1->m_isDashing;
                    m_fields->timedHoldDashWaitStepsRemaining = std::max(32, 8 * std::max(1, g_frameSubsteps));
                    break;
                case BotAction::DelayedDashHold:
                    this->cancelTap();
                    this->cancelOrbTapSchedule();
                    this->cancelTimedHold();
                    this->cancelWaveTransition();
                    this->releaseBot();
                    m_fields->dashHoldScheduled = true;
                    m_fields->dashHoldStepsRemaining = std::max(
                        std::max(1, g_frameSubsteps), selectedDashHoldDelaySteps
                    );
                    m_fields->dashHoldDurationSteps = selectedDashHoldSteps;
                    break;
                case BotAction::DelayedTap:
                    this->cancelTap();
                    this->cancelTimedHold();
                    this->cancelWaveTransition();
                    this->releaseBot();
                    m_fields->orbTapScheduled = true;
                    m_fields->orbTapStepsRemaining = std::max(
                        std::max(1, g_frameSubsteps), selectedOrbTapDelaySteps
                    );
                    break;
                case BotAction::Tap:
                    this->cancelOrbTapSchedule();
                    this->cancelTimedHold();
                    // SimPlan::Tap always starts from released input. Mirror
                    // that edge in the live game even when a previous Hold
                    // left Jump down; otherwise an orb/cube tap is swallowed.
                    if (requiresFreshPressEdge(action, m_fields->botHolding)) this->releaseBot();
                    this->pressBot();
                    m_fields->botTapActive = true;
                    m_fields->botTapStepsRemaining = std::max(1, g_frameSubsteps);
                    break;
                case BotAction::Release:
                default:
                    this->cancelTap();
                    if (!orbTapForced && !dashHoldForced) this->cancelOrbTapSchedule();
                    this->cancelTimedHold();
                    this->releaseBot();
                    break;
            }
        } else {
            this->releaseBot();
            this->cancelTap();
            this->cancelOrbTapSchedule();
            this->cancelWaveTransition();
            this->cancelTimedHold();
        }
    }

    void onQuit() {
        this->releaseBot();
        this->cancelTap();
        this->cancelOrbTapSchedule();
        this->cancelWaveTransition();
        this->cancelTimedHold();

        if (g_performanceScheduler == &m_fields->scheduler) g_performanceScheduler = nullptr;
        m_fields->drawNode = nullptr;
        m_fields->panel = nullptr;
        m_fields->panelTouch = nullptr;
        m_fields->headerLabel = nullptr;
        m_fields->scanLabel = nullptr;
        m_fields->dummy1 = nullptr;
        m_fields->dummy2 = nullptr;
        m_fields->menu = nullptr;
        m_fields->autoLabel = nullptr;
        m_fields->trajLabel = nullptr;
        m_fields->waveLabel = nullptr;
        m_fields->deviceLabel = nullptr;
        m_fields->planLabel = nullptr;
        m_fields->adaptiveLabel = nullptr;
        m_fields->metricsLabel = nullptr;
        m_fields->statusLabel = nullptr;

        PlayLayer::onQuit();
    }
};

$on_mod(Loaded) {
    log::info("Auto Trajectory v0.7.0 loaded");
}
