#include <cassert>
#include <cmath>
#include <iostream>
#include "../src/core/planning/SegmentPlanner.hpp"
#include "../src/core/planning/GlobalRoutePlanner.hpp"
#include "../src/core/planning/WavePlanner2.hpp"

int main() {
    using namespace at::planning;
    auto window = makeSegmentWindow(2, 100.f, 200.f, 2.f, 120);
    assert(window.checkpoint == 2 && window.distance == 100.f && window.maxSteps == 50);
    auto capped = makeSegmentWindow(1, 0.f, 500.f, 0.f, 72);
    assert(capped.maxSteps == 72);
    SegmentScore score{80, 100, 5, 2, 1, 0, false, 0.f};
    assert(scoreSegment(score) > 0.f && scoreSegment(score) < 1.f);

    std::array<std::array<float, 2>, 4> risk{{
        {{0.7f, 0.1f}}, {{0.1f, 0.8f}}, {{0.6f, 0.2f}}, {{0.2f, 0.7f}}
    }};
    auto route = planGlobalRoute(risk, false, 8);
    assert(route.valid && route.controls[0] && !route.controls[1]);
    assert(route.controls[2] && !route.controls[3]);
    assert(route.switches >= 1 && route.risk < 0.5f);

    auto wave = generateWaveCandidates(false, 4, 108, 12, 2);
    assert(wave.size() == 12);
    assert(!wave[0].startHolding && wave[0].switchCount == 0);
    assert(wave[1].startHolding && wave[1].switchCount == 0);
    bool foundTwoSwitch = false;
    for (auto const& c : wave) if (c.switchCount == 2) foundTwoSwitch = true;
    assert(foundTwoSwitch);
    for (auto const& c : wave) {
        int previous = 0;
        for (int i = 0; i < c.switchCount; ++i) {
            assert(c.switchSteps[static_cast<std::size_t>(i)] > previous);
            assert(c.switchSteps[static_cast<std::size_t>(i)] < 108);
            previous = c.switchSteps[static_cast<std::size_t>(i)];
        }
    }
    std::cout << "planning modules: ok\n";
}
