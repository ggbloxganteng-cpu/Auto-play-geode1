// Wave: compares classic, lightweight and deep scheduled planners.
#include "stubs.hpp"
using namespace cocos2d;
#include "../src/core/Simulation.hpp"
#include <random>

// ---- old controller (v0.3.0) kept for comparison ----
static BotAction oldWave(SimRig const& rig, SimResult const& idle, int botSteps, bool holding) {
  if (!(idle.died && idle.survived < botSteps)) return BotAction::Release;
  SimResult hold = probe(rig, SimPlan::Hold, 0, -1, botSteps);
  if (!hold.died && idle.died) return BotAction::Hold;
  if (hold.died && !idle.died) return BotAction::Release;
  if (!hold.died && !idle.died) return holding ? BotAction::Hold : BotAction::Release;
  if (hold.survived > idle.survived + kFlySwitchMargin) return BotAction::Hold;
  if (idle.survived > hold.survived + kFlySwitchMargin) return BotAction::Release;
  return holding ? BotAction::Hold : BotAction::Release;
}

// returns x reached (died) or end
static long long gFrames=0;
static bool flyWave(World& w, int profile, int look, float endX, float* diedAt) {
  bool useNew = profile != 0;
  PlayLayer pl; PlayerObject r, d; r.world=&w; d.world=&w; r.m_isDart=d.m_isDart=true; r.y=120;
  g_frameSubsteps=4; bool holding=false; int frames=0;
  bool scheduled=false; int untilSwitch=0; bool switchToHold=false;
  while (r.x < endX && frames < 6000) {
    ++frames; ++gFrames;
    for (int i=0;i<4;i++){
      if (holding) r.pushButton(PlayerButton::Jump); else r.releaseButton(PlayerButton::Jump);
      r.update(0.25f); pl.checkCollisions(&r,0.25f,false);
      if (r.m_isDead) { *diedAt=r.x; return false; }
    }
    SimRig rig; rig.pl=&pl; rig.dummy=&d; rig.source=&r; rig.dt=0.25f;
    rig.roomAwareWave = useNew;
    rig.deepWaveSearch = profile == 2;
    SimResult idle = runSimulation(rig,SimPlan::Release,0,-1,look,0,nullptr,kNoColor);

    if (useNew && scheduled) {
      untilSwitch -= 4;
      if (untilSwitch <= 0) {
        holding = switchToHold;
        scheduled = false;
        continue;
      }
      SimResult current = probe(rig, holding ? SimPlan::Hold : SimPlan::Release, 0, -1,
                                std::min(untilSwitch, look));
      if (!current.died || current.survived >= std::min(untilSwitch, look)) continue;
      scheduled = false; // current segment became unsafe; re-plan now
    }

    WavePlan plan;
    BotAction a = useNew
      ? decideAutoPress(rig,idle,look,holding,&plan)
      : oldWave(rig,idle,look,holding);
    holding = (a != BotAction::Release);
    if (useNew && plan.switchCount > 0) {
      scheduled = true;
      untilSwitch = plan.switchSteps[0];
      switchToHold = !plan.startHolding;
    }
  }
  return true;
}

int main(){
  struct Mode { const char* name; int hmin, hmax, smin, smax; bool dbl; } modes[] = {
    {"single gaps, tight",         14, 24, 110, 180, false},
    {"single gaps, very tight",    11, 16, 100, 150, false},
    {"two gaps (tight + wide)",    11, 14, 130, 200, true},
  };
  for (auto& m : modes) for (int look : {132, 200}) {
    int total=0, oldDied=0, lightDied=0, deepDied=0; double costOld=0, costLight=0, costDeep=0;
    std::mt19937 rng(99);
    for (int t=0;t<300;t++) {
      World w; w.H=240; float x=500; float c=120;
      int n = 7 + rng()%5;
      for (int g=0; g<n; g++) {
        float spacing = m.smin + rng()%(m.smax-m.smin+1);
        float maxMove = spacing*0.5f;
        float move = ((int)(rng()%2001)-1000)/1000.f * maxMove;
        c = std::max(40.f, std::min(200.f, c+move));
        float h = m.hmin + rng()%(m.hmax-m.hmin+1);
        Gate gt{x, c-h, c+h};
        if (m.dbl) { // second, much wider gap somewhere else on the same wall
          float c2 = (c > 120) ? c-70 : c+70; float h2 = 38;
          gt.lo2 = c2-h2; gt.hi2 = c2+h2;
        }
        w.gates.push_back(gt);
        x += spacing;
      }
      float end = x+300; float at;
      g_simStepCount=0; gFrames=0; bool okOld = flyWave(w,0,look,end,&at); costOld += (double)g_simStepCount/gFrames;
      g_simStepCount=0; gFrames=0; bool okLight = flyWave(w,1,look,end,&at); costLight += (double)g_simStepCount/gFrames;
      g_simStepCount=0; gFrames=0; bool okDeep = flyWave(w,2,look,end,&at); costDeep += (double)g_simStepCount/gFrames;
      total++; oldDied += !okOld; lightDied += !okLight; deepDied += !okDeep;
    }
    printf("%-26s look=%d: classic %3d/%d (%4.0f steps/frame)  light %3d/%d (%4.0f)  deep %3d/%d (%4.0f)\n",
      m.name, look, oldDied,total,costOld/total,lightDied,total,costLight/total,deepDied,total,costDeep/total);
  }
}
