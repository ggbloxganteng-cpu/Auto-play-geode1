// Toy world used by tests/run.sh and tests/fuzz.cpp
#pragma once
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <initializer_list>
#include <utility>
#include <array>
#include <unordered_set>
namespace cocos2d {
 struct CCPoint { float x=0,y=0; };
 struct CCRect {
   float x=0,y=0,w=0,h=0;
   float getMinX() const { return x; } float getMaxX() const { return x+w; }
   float getMinY() const { return y; } float getMaxY() const { return y+h; }
   bool intersectsRect(CCRect const& o) const {
     return getMaxX() >= o.getMinX() && o.getMaxX() >= getMinX() &&
            getMaxY() >= o.getMinY() && o.getMaxY() >= getMinY();
   }
 };
 struct ccColor4F { float r,g,b,a; };
 struct CCArray { void removeAllObjects(){} };
 struct CCDrawNode { void drawDot(CCPoint,float,ccColor4F){} void drawSegment(CCPoint,CCPoint,float,ccColor4F){} };
}
enum class PlayerButton { Jump = 1 };
enum class GameObjectType {
  Solid, Hazard, AnimatedHazard, CollisionObject, Slope, Decoration,
  YellowJumpPad, PinkJumpPad, RedJumpPad, GravityPad, SpiderPad,
  YellowJumpRing, PinkJumpRing, RedJumpRing, GravityRing, GreenRing,
  DropRing, CustomRing, DashRing, GravityDashRing, SpiderOrb,
  InverseGravityPortal, NormalGravityPortal, GravityTogglePortal, TeleportOrb
};
struct Spike { float x; };
struct Plat { float x1,x2,h; };
struct Gate { float x, lo, hi, lo2=-1, hi2=-1; };
struct World { std::vector<Gate> gates; std::vector<Spike> spikes; std::vector<Plat> plats; std::vector<Spike> floorSp, ceilSp; float H=240; };
struct GameObject {
  int m_objectID=0; float px=0,py=0; bool m_isActivated=false;
  GameObjectType m_objectType=GameObjectType::Solid;
  float getPositionX(){return px;} float getPositionY(){return py;}
  cocos2d::CCRect getObjectRect(){ return {px-10,py-10,20,20}; }
  virtual ~GameObject() = default;
};
struct EffectGameObject : GameObject {
  bool m_activated=false, m_activatedByPlayer1=false, m_activatedByPlayer2=false;
};
struct RingObject : EffectGameObject {};
template <class T> T typeinfo_cast(GameObject* p) { return dynamic_cast<T>(p); }
struct PlayerObject : GameObject {
  float x=0,y=0,vy=0; bool m_isOnGround=true, m_isDead=false, holding=false;
  bool m_isShip=false,m_isBird=false,m_isDart=false,m_isSwing=false,m_isRobot=false,m_isBall=false,m_isSpider=false,m_isUpsideDown=false;
  bool wasHoldingLastUpdate=false;
  int heldUpdates=0;
  float m_width=30,m_height=30,m_gravityMod=1,m_vehicleSize=1,m_playerSpeed=1;
  bool m_isDashing=false, m_holdingButtons=false, m_jumpBuffered=false, m_wasJumpBuffered=false;
  bool m_stateJumpBuffered=false, m_stateRingJump=false, m_stateRingJump2=false, m_wasRobotJump=false;
  bool m_touchedPad=false, m_touchedGravityPortal=false;
  GameObject* m_lastActivatedPortal=nullptr;
  GameObject* m_touchedRing=nullptr;
  World* world=nullptr;
  cocos2d::CCArray *m_collisionLogTop=nullptr,*m_collisionLogBottom=nullptr,*m_collisionLogLeft=nullptr,*m_collisionLogRight=nullptr;
  int m_lastCollisionTop,m_lastCollisionBottom,m_lastCollisionLeft,m_lastCollisionRight;
  void setVisible(bool){} void setScale(float){} float getScale(){return 1;}
  void setContentSize(int){} int getContentSize(){return 0;}
  void resetTouchedRings(bool) { m_touchedRing=nullptr; }
  cocos2d::CCRect getObjectRect(){ return {x-m_width*0.5f,y-m_height*0.5f,m_width,m_height}; }
  void copyAttributes(PlayerObject* s){ x=s->x;y=s->y;vy=s->vy;m_isOnGround=s->m_isOnGround;m_isDead=false; holding=s->holding;
     world=s->world; m_isShip=s->m_isShip; m_isDart=s->m_isDart; m_isRobot=s->m_isRobot;
     m_isBall=s->m_isBall; m_isSpider=s->m_isSpider; m_isUpsideDown=s->m_isUpsideDown;
     wasHoldingLastUpdate=false; heldUpdates=0; }
  void setPosition(cocos2d::CCPoint p){ x=p.x; y=p.y; }
  float getPositionX(){return x;} float getPositionY(){return y;}
  cocos2d::CCPoint getPosition(){ return {x,y}; }
  void pushButton(PlayerButton){ holding=true; }
  void releaseButton(PlayerButton){ holding=false; }
  void update(float dt){
    if (holding) ++heldUpdates;
    x += 5.193f*dt;
    if (m_isBall) {
      if (holding && !wasHoldingLastUpdate) { m_isUpsideDown = !m_isUpsideDown; vy = 0.f; }
      wasHoldingLastUpdate = holding;
      vy += (m_isUpsideDown ? 1.f : -1.f) * 0.958f * dt;
      y += vy * dt;
      if (y < 0.f) { y = 0.f; vy = 0.f; m_isOnGround = !m_isUpsideDown; }
      if (y > world->H - 30.f) { y = world->H - 30.f; vy = 0.f; m_isOnGround = m_isUpsideDown; }
      return;
    }
    if (m_isDart) { // wave: 45 degree slope up while held, down otherwise; floor/ceiling are safe
      y += (holding ? 1.f : -1.f) * 5.193f*dt;
      if (y < 0) y = 0; if (y > world->H-10) y = world->H-10;
      return;
    }
    if (m_isShip) {
      vy += (holding ? 0.8f : -0.8f)*dt; vy = std::max(-8.f, std::min(8.f, vy));
      y += vy*dt;
      if (y < 0) { y = 0; vy = 0; } if (y > world->H-30) { y = world->H-30; vy = 0; }
      return;
    }
    if (m_isOnGround && holding) { vy = 11.18f; m_isOnGround=false; }
    if (!m_isOnGround) { y += vy*dt; vy -= 0.958f*dt; }
  }
};
struct PlayLayer {
  void checkCollisions(PlayerObject* p, float, bool){
    World& w = *p->world;
    if (p->m_isDart) {
      for (auto& g: w.gates) if (std::fabs(p->x - g.x) < 10.f) {
        bool in1 = !(p->y < g.lo || p->y + 10.f > g.hi);
        bool in2 = g.lo2 >= 0 && !(p->y < g.lo2 || p->y + 10.f > g.hi2);
        if (!in1 && !in2) { p->m_isDead = true; return; } }
      return;
    }
    if (p->m_isShip) {
      for (auto& s: w.floorSp) if (std::fabs(p->x - s.x) < 10.f && p->y < 18.f) { p->m_isDead = true; return; }
      for (auto& s: w.ceilSp)  if (std::fabs(p->x - s.x) < 10.f && p->y + 30 > w.H - 18.f) { p->m_isDead = true; return; }
      return;
    }
    const float hw=15;
    for (auto& s: w.spikes) if (std::fabs(p->x - s.x) < 10.f && p->y < 12.f) { p->m_isDead = true; return; }
    float support = 0;
    for (auto& pl: w.plats) {
      if (p->x+hw > pl.x1 && p->x-hw < pl.x2) {
        if (p->y >= pl.h - 8.f) { if (p->vy <= 0 || p->m_isOnGround) support = std::max(support, pl.h); }
        else { p->m_isDead = true; return; }
      }
    }
    if (p->y <= support && p->vy <= 0) { p->y = support; p->vy = 0; p->m_isOnGround = true; }
    else if (p->y > support + 0.01f) p->m_isOnGround = false;
  }
};
