#include <cassert>
#include <cstdio>
#include "../src/core/LevelScan.hpp"

int main() {
    at::LevelScan scan;
    scan.build({
        {0.f, 1, at::ObjectClass::Other},
        {100.f, 2, at::ObjectClass::Hazard},
        {250.f, 3, at::ObjectClass::Orb},
        {500.f, 4, at::ObjectClass::Pad},
        {750.f, 5, at::ObjectClass::Portal},
        {1000.f, 6, at::ObjectClass::Hazard},
    });
    assert(scan.valid());
    assert(scan.objectCount() == 6);
    assert(scan.checkpointFor(0.f) == 0);
    assert(scan.checkpointFor(250.f) == 1);
    assert(scan.checkpointFor(500.f) == 2);
    assert(scan.checkpointFor(750.f) == 3);
    assert(scan.progressPercent(500.f) == 50);
    assert(scan.checkpoint(0)->hazards == 1);
    assert(scan.checkpoint(1)->orbs == 1);
    assert(scan.checkpoint(2)->pads == 1);
    assert(scan.checkpoint(3)->portals == 1);

    // A scan started after every object must still have non-negative bounds.
    scan.build({
        {10.f, 1, at::ObjectClass::Hazard},
        {20.f, 2, at::ObjectClass::Orb},
    }, 100.f);
    assert(scan.valid());
    assert(scan.minX() == 10.f);
    assert(scan.maxX() == 20.f);
    assert(scan.progressPercent(100.f) == 100);

    scan.build({});
    assert(!scan.valid());
    assert(scan.progressPercent(500.f) == 0);
    std::puts("level scanner: ok");
}
