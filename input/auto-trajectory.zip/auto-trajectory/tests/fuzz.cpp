#define main main_orig
#include "run.cpp"
#undef main
#include <random>
int main(){
  std::mt19937 rng(12345);
  auto R=[&](int a,int b){ return std::uniform_int_distribution<int>(a,b)(rng); };
  struct Cfg { int look; int sp; } cfgs[] = {{132,4},{240,4},{240,2},{240,8},{200,4}};
  for (auto cfg : cfgs) {
    int died=0, total=0, maxPressPerObs=0; double pressSum=0, obsSum=0;
    std::mt19937 r2(777);
    for (int t=0;t<400;t++) {
      World w; float x=600; int obs=0;
      int nseg = 3 + (int)(r2()%4);
      for (int s=0;s<nseg;s++) {
        int kind = r2()%5;
        if (kind==0) { w.spikes.push_back({x}); obs++; x+=30; }
        else if (kind==1) { w.spikes.push_back({x}); w.spikes.push_back({x+30}); obs++; x+=60; }
        else if (kind==2) { // single 1-block with gap after
          w.plats.push_back({x-15,x+15,30}); obs++; x+=30; }
        else if (kind==3) { // SM staircase 1,2,3 spaced 3 blocks apart (gap 90 units between)
          float bx=x; for (int k=1;k<=3;k++){ w.plats.push_back({bx-15,bx+15,30.f*k}); bx+=120; } obs+=3; x=bx; }
        else { // spike then block
          w.spikes.push_back({x}); w.plats.push_back({x+40,x+70,30}); obs+=2; x+=70; }
        x += 150 + (r2()%250);
      }
      w.spikes.push_back({x+200});
      Out o = play(w,nullptr,false,cfg.look,x+600,false,cfg.sp);
      total++; if (o.died) died++;
      pressSum += o.presses; obsSum += obs+1;
    }
    printf("look=%d substeps/frame=%d: died %d / %d layouts   presses per obstacle %.2f\n", cfg.look, cfg.sp, died, total, pressSum/obsSum);
  }
}
