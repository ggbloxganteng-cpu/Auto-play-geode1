// Straight fly: ship / wave hold their altitude through free stretches without
// dying more often than the old "just release" behaviour.
#include "stubs.hpp"
using namespace cocos2d;
#include "../src/core/Simulation.hpp"
#include <random>
#ifndef SP_MIN
#define SP_MIN 90
#define SP_RANGE 60
#define GATE_MIN 34
#endif

struct Out { bool died=false; float diedAt=0; float maxDev=0; float avgDev=0; };

static Out fly(World& w, bool ship, bool useHover, int look, float endX, float y0) {
  PlayLayer pl; PlayerObject r, d; r.world=&w; d.world=&w;
  r.m_isShip = d.m_isShip = ship; r.m_isDart = d.m_isDart = !ship; r.y = y0;
  g_frameSubsteps = 4; bool holding=false; int frames=0; HoverState hs;
  Out o; double sum=0; int n=0;
  while (r.x < endX && frames < 8000) {
    ++frames;
    for (int i=0;i<4;i++){
      if (holding) r.pushButton(PlayerButton::Jump); else r.releaseButton(PlayerButton::Jump);
      r.update(0.25f); pl.checkCollisions(&r,0.25f,false);
      if (r.m_isDead) { o.died=true; o.diedAt=r.x; return o; }
    }
    if (frames > 90 && hs.active) { float dv = std::fabs(r.y - hs.targetY); o.maxDev=std::max(o.maxDev,dv); sum+=dv; ++n; }
    SimRig rig; rig.pl=&pl; rig.dummy=&d; rig.source=&r; rig.dt=0.25f;
    SimResult idle = runSimulation(rig,SimPlan::Release,0,-1,look,0,nullptr,kNoColor);
    BotAction a = decideAutoPress(rig,idle,look,holding,nullptr,nullptr,nullptr, useHover ? &hs : nullptr);
    holding = (a == BotAction::Hold || a == BotAction::Tap);
  }
  o.avgDev = n ? (float)(sum/n) : 0;
  return o;
}

int main(){
  int fails = 0;
  // 1) Empty corridor: altitude must stay near the target; the old behaviour sinks.
  for (bool ship : {true, false}) {
    World w; w.H = 300;
    Out oldR = fly(w, ship, false, 132, 6000, 150);
    Out newR = fly(w, ship, true, 132, 6000, 150);
    std::printf("%-5s empty corridor: old sinks to y-dev?  new maxDev=%.1f avgDev=%.1f died=%d\n",
                ship ? "ship" : "wave", newR.maxDev, newR.avgDev, newR.died);
    if (newR.died || newR.maxDev > 25.f) { std::printf("  FAIL: not straight enough\n"); ++fails; }
    (void)oldR;
  }

  // 2) Random hazards: hover must not die more often than releasing.
  for (bool ship : {true, false}) {
    int oldDied=0, newDied=0, total=200;
    std::mt19937 rng(7);
    for (int t=0;t<total;t++) {
      World w; w.H = 300;
      float x = 500;
      int n = 10 + rng()%6;
      for (int g=0; g<n; g++) {
        x += SP_MIN + rng()%SP_RANGE;
        if (ship) { if (rng()%2) w.floorSp.push_back({x}); else w.ceilSp.push_back({x}); }
        else { float lo = 40 + rng()%120; w.gates.push_back({x, lo, lo + GATE_MIN + (float)(rng()%40)}); }
      }
      float endX = x + 200; float y0 = 100 + rng()%100;
      if (fly(w, ship, false, 200, endX, y0).died) ++oldDied;
      if (fly(w, ship, true,  200, endX, y0).died) ++newDied;
    }
    std::printf("%-5s random hazards: old died %d/%d, straight-fly died %d/%d\n",
                ship ? "ship" : "wave", oldDied, total, newDied, total);
    if (newDied > oldDied + total/50) { std::printf("  FAIL: straight fly dies noticeably more\n"); ++fails; }
  }
  std::printf(fails ? "HOVER TESTS FAILED\n" : "hover tests OK\n");
  return fails ? 1 : 0;
}
