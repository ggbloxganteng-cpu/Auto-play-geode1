#!/bin/sh
# Offline test of the bot's decision logic against a toy physics model.
# Compiles the same portable engine module included by src/main.cpp.
set -e
cd "$(dirname "$0")"
trap 'rm -f run fuzz wave interactions levelscan performance planning hover levelstrategy' EXIT
g++ -std=c++20 -O2 -Wno-unused -Wno-unused-function -o run run.cpp
g++ -std=c++20 -O2 -Wno-unused -Wno-unused-function -o fuzz fuzz.cpp
g++ -std=c++20 -O2 -Wno-unused -Wno-unused-function -o wave wave.cpp
g++ -std=c++20 -O2 -Wno-unused -Wno-unused-function -o interactions interactions.cpp
g++ -std=c++20 -O2 -Wall -Wextra -o levelscan levelscan.cpp
./run
./fuzz
./wave
./interactions
./levelscan
g++ -std=c++20 -O2 -Wall -Wextra -o performance performance.cpp
./performance

g++ -std=c++20 -O2 -Wall -Wextra -o planning planning.cpp
./planning

g++ -std=c++20 -O2 -Wno-unused -Wno-unused-function -o hover hover.cpp
./hover

g++ -std=c++20 -O2 -Wall -Wextra -o levelstrategy levelstrategy.cpp
./levelstrategy
