#include "../src/core/performance/LevelStrategyProfile.hpp"

#include <cassert>
#include <iostream>

using namespace at::performance;

int main() {
    LevelStrategyProfile profile;
    assert(profile.chooseNext(Preset::Balanced) == Preset::Balanced);
    profile.record(Preset::Balanced, 42, false);
    assert(profile.chooseNext(Preset::Balanced) == Preset::High);
    profile.record(Preset::High, 78, false);
    assert(profile.chooseNext(Preset::Balanced) == Preset::UltraLow);
    profile.record(Preset::UltraLow, 31, false);
    assert(profile.chooseNext(Preset::Balanced) == Preset::Low);
    profile.record(Preset::Low, 55, true);

    // The winning per-level profile is chosen by observed progress with a
    // modest penalty for prediction misses; ties prefer the cheaper preset.
    assert(profile.chooseNext(Preset::Balanced) == Preset::High);

    // Save/load must preserve attempt counts and scores for persistent storage.
    LevelStrategyProfile restored;
    for (int i = 0; i < 4; ++i) restored.load(i, profile.save(i));
    assert(restored.chooseNext(Preset::Balanced) == Preset::High);
    assert(restored.stats(3).attempts == 1);
    assert(restored.stats(3).bestProgress == 78);
    assert(restored.stats(1).predictionMisses == 1);

    std::cout << "level strategy tests: ok\n";
    return 0;
}
