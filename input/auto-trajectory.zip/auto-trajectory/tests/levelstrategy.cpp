#include "../src/core/performance/LevelStrategyProfile.hpp"

#include <cassert>
#include <iostream>

using namespace at::performance;

int main() {
    LevelStrategyProfile profile;
    assert(profile.recommendation(Preset::Balanced) == Preset::Balanced);
    profile.record(Preset::Balanced, 42, false);
    assert(profile.recommendation(Preset::Balanced) == Preset::Balanced);
    profile.record(Preset::High, 78, false);
    assert(profile.recommendation(Preset::Balanced) == Preset::High);
    profile.record(Preset::UltraLow, 31, false);
    assert(profile.recommendation(Preset::Balanced) == Preset::High);
    profile.record(Preset::Low, 55, true);

    // Recommendation is advisory only. The caller's selected plan is not
    // changed by recording a death or asking for the recommendation.
    const Preset manuallySelectedPlan = Preset::Low;
    assert(profile.recommendation(manuallySelectedPlan) == Preset::High);
    assert(manuallySelectedPlan == Preset::Low);

    // Save/load must preserve attempt counts and scores for persistent storage.
    LevelStrategyProfile restored;
    for (int i = 0; i < 4; ++i) restored.load(i, profile.save(i));
    assert(restored.recommendation(Preset::Balanced) == Preset::High);
    assert(restored.stats(3).attempts == 1);
    assert(restored.stats(3).bestProgress == 78);
    assert(restored.stats(1).predictionMisses == 1);

    std::cout << "level strategy tests: ok\n";
    return 0;
}
