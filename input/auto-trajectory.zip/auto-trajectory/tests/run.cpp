#include "stubs.hpp"
using namespace cocos2d;
#include "../src/core/Simulation.hpp"

struct Bot {
  bool holding=false, tapActive=false;
  int timedHoldRemaining=0;
};
struct Out { bool died; float x; int presses; };

// Mirrors the live controller pulse scheduling used by the v0.5.x line (one-frame tap pulses).
Out play(World& w1, World* w2, bool ship, int botSteps, float endX, bool verbose=false, int subPerFrame=4) {
  PlayLayer pl;
  PlayerObject r1, r2, d1, d2; r1.world=&w1; d1.world=&w1; r1.m_isShip=d1.m_isShip=ship;
  if (w2) { r2.world=w2; d2.world=w2; r2.m_isShip=d2.m_isShip=ship; }
  if (ship) { r1.y=100; if (w2) r2.y=100; }
  Bot bot; int presses=0, frames=0; g_frameSubsteps = subPerFrame;
  while (r1.x < endX && frames < 6000) {
    ++frames;
    for (int i=0;i<subPerFrame;i++){
      if (bot.holding) { r1.pushButton(PlayerButton::Jump); if(w2) r2.pushButton(PlayerButton::Jump);} else { r1.releaseButton(PlayerButton::Jump); if(w2) r2.releaseButton(PlayerButton::Jump);}
      r1.update(0.25f); pl.checkCollisions(&r1,0.25f,false);
      if (w2) { r2.update(0.25f); pl.checkCollisions(&r2,0.25f,false); }
      if (r1.m_isDead || (w2&&r2.m_isDead)) return {true, r1.x, presses};
    }
    SimRig rig; rig.pl=&pl; rig.dummy=&d1; rig.source=&r1; rig.dt=0.25f;
    if (w2) { rig.dummy2=&d2; rig.source2=&r2; }
    SimResult idle = runSimulation(rig,SimPlan::Release,0,-1,botSteps,0,nullptr,kNoColor);
    bool timedForced=false, timedJustReleased=false;
    if (bot.timedHoldRemaining > 0) {
      bot.timedHoldRemaining -= subPerFrame;
      if (bot.timedHoldRemaining <= 0) {
        bot.holding=false;
        timedJustReleased=true;
      } else timedForced=true;
    }
    // The preceding Tap was held for this complete frame. Release it now and
    // let the planner inspect the actual state instead of lock-holding to land.
    if (bot.tapActive) { bot.holding=false; bot.tapActive=false; }
    int timedSteps=0;
    BotAction a = timedForced ? BotAction::Hold : (timedJustReleased ? BotAction::Release :
      decideAutoPress(rig,idle,botSteps,bot.holding,nullptr,&timedSteps));
    bool was=bot.holding;
    bool freshPress=false;
    switch(a){
      case BotAction::Hold:
        bot.tapActive=false; bot.holding=true; break;
      case BotAction::TimedHold:
        bot.tapActive=false;
        if (bot.holding) { bot.holding=false; freshPress=true; }
        bot.holding=true; bot.timedHoldRemaining=std::max(subPerFrame,timedSteps); break;
      case BotAction::Tap:
        // A Tap is one complete frame and always starts from a fresh edge.
        bot.holding=false; bot.holding=true; freshPress=true;
        bot.tapActive=true; break;
      default:
        bot.tapActive=false; bot.timedHoldRemaining=0; bot.holding=false; break;
    }
    if ((bot.holding && !was) || freshPress) { ++presses; if (verbose) printf("  press f=%d x=%.0f y=%.1f gnd=%d act=%d\n",frames,r1.x,r1.y,r1.m_isOnGround,(int)a); }
  }
  return {false, r1.x, presses};
}
static const char* fmt(Out o){ static char b[16][48]; static int k=0; char*s=b[k++%16]; snprintf(s,48,"%s p=%d", o.died?"DIED":"ok", o.presses); return s; }

int main(int argc,char**argv){
  bool verbose = argc>1;
  // ---- Stereo Madness chain (from the screenshot): spikes, 1-block, 2-pillar, 3-pillar
  printf("== Stereo Madness chain (cube)\n");
  for (int look : {132, 160, 200, 240, 300}) {
    World w; w.spikes={{572},{602}}; w.plats={{620,650,30},{744,774,60},{869,899,90}}; w.spikes.push_back({1300});
    Out o = play(w,nullptr,false,look,1500, verbose && look==240);
    printf("  look=%-3d %s (x=%.0f)\n", look, fmt(o), o.x);
  }
  // ---- earlier cube cases
  printf("== plain spike layouts (cube), lookahead 240 / 132\n");
  struct C { const char* n; std::vector<float> s; } cs[] = {
    {"1 spike",{600}}, {"2 spikes 7 blocks",{600,810}}, {"2 spikes 4 blocks",{600,720}},
    {"3 adjacent",{600,630,660}}, {"4 singles",{600,900,1200,1500}}, {"empty (far spike)",{3000}}};
  for (auto& c: cs) {
    World a; for(float x: c.s) a.spikes.push_back({x});
    World b = a;
    float end = c.s.back()+400;
    printf("  %-18s look240: %-10s look132: %-10s\n", c.n, fmt(play(a,nullptr,false,240,end)), fmt(play(b,nullptr,false,132,end)));
  }
  printf("== different fps (substeps/frame), SM chain, look 240\n");
  for (int sp : {1,2,4,6,8}) {
    World w; w.spikes={{572},{602}}; w.plats={{620,650,30},{744,774,60},{869,899,90}}; w.spikes.push_back({1300});
    Out o = play(w,nullptr,false,240,1500,false,sp);
    printf("  substeps/frame=%d %s\n", sp, fmt(o));
  }
  // ---- dual: both players share input, each has its own hazards
  printf("== dual mode (two cubes, shared input)\n");
  { World a, b; a.spikes={{600},{900}}; b.spikes={{750},{1050}};
    printf("  look240 %s\n", fmt(play(a,&b,false,240,1300))); }
  { World a, b; a.spikes={{600}}; b.spikes={{600}};
    printf("  same spot %s\n", fmt(play(a,&b,false,240,900))); }
  // ---- ship: slalom between floor and ceiling spikes
  printf("== ship slalom\n");
  for (int look : {100, 160, 240}) {
    World w; for (int k=0;k<8;k++){ float x=500+k*160; if(k%2==0) w.floorSp.push_back({x}); else w.ceilSp.push_back({x}); }
    printf("  look=%d %s\n", look, fmt(play(w,nullptr,true,look,2100)));
  }
  return 0;
}
