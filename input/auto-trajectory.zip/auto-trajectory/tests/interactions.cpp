#include "stubs.hpp"
using namespace cocos2d;
#include "../src/core/Simulation.hpp"
#include "../src/core/performance/LevelStrategyProfile.hpp"
#include <cassert>

int main() {
    // Activation state touched by a simulation must be restored afterwards.
    EffectGameObject pad;
    pad.m_objectType = GameObjectType::YellowJumpPad;
    pad.m_isActivated = false;
    pad.m_activated = false;
    pad.m_activatedByPlayer1 = false;
    pad.m_activatedByPlayer2 = true;
    assert(isSimInteractable(&pad));
    snapshotSimObject(&pad);
    pad.m_isActivated = true;
    pad.m_activated = true;
    pad.m_activatedByPlayer1 = true;
    pad.m_activatedByPlayer2 = false;
    restoreSimObjects();
    assert(!pad.m_isActivated);
    assert(!pad.m_activated);
    assert(!pad.m_activatedByPlayer1);
    assert(pad.m_activatedByPlayer2);

    // No-Touch may rewrite the object type to Decoration; RTTI must still
    // identify the runtime RingObject so the orb is not filtered out.
    RingObject ring;
    ring.m_objectType = GameObjectType::Decoration;
    assert(isSimInteractable(&ring));
    PlayerObject ghostP1, ghostP2;
    g_simDummies[0] = &ghostP1;
    g_simDummies[1] = &ghostP2;
    ring.m_activatedByPlayer1 = false;
    ring.m_activatedByPlayer2 = true;
    ring.m_activated = false;
    assert(ringUnusedByDummy(&ring, &ghostP1));
    assert(!ringUnusedByDummy(&ring, &ghostP2));
    assert(!ringCanActivateForDummy(&ring, &ghostP1, false));
    assert(ringCanActivateForDummy(&ring, &ghostP1, true));
    assert(!ringCanActivateForDummy(&ring, &ghostP2, true));

    // Orb contact and activation are tracked separately. Repeated broad-phase
    // checks for one RingObject count once, and the first contact step is kept.
    resetSimOrbTracking();
    recordSimOrbContact(&ring, 12);
    recordSimOrbContact(&ring, 14);
    assert(g_simOrbContactCount == 1);
    assert(g_simFirstOrbContactStep == 12);
    recordSimOrbActivation(&ring, 13);
    recordSimOrbActivation(&ring, 15);
    assert(g_simOrbActivationCount == 1);
    assert(g_simFirstOrbActivationStep == 13);

    // Dash Orbs must be separated from ordinary jump orbs. The green and
    // pink variants are identified by their 2.2081 object IDs and runtime types.
    RingObject greenDashOrb;
    greenDashOrb.m_objectID = 1704;
    RingObject pinkGravityDashOrb;
    pinkGravityDashOrb.m_objectID = 1751;
    RingObject typedDashOrb;
    typedDashOrb.m_objectType = GameObjectType::DashRing;
    RingObject typedGravityDashOrb;
    typedGravityDashOrb.m_objectType = GameObjectType::GravityDashRing;
    assert(isDashOrb(&greenDashOrb));
    assert(isDashOrb(&pinkGravityDashOrb));
    assert(isDashOrb(&typedDashOrb));
    assert(isDashOrb(&typedGravityDashOrb));
    assert(!isDashOrb(&ring));
    RingObject spiderOrb;
    spiderOrb.m_objectType = GameObjectType::SpiderOrb;
    assert(isSpiderOrb(&spiderOrb));
    RingObject spiderOrbById;
    spiderOrbById.m_objectID = 3004;
    spiderOrbById.m_objectType = GameObjectType::Decoration;
    assert(isSpiderOrb(&spiderOrbById));
    assert(isSimInteractable(&spiderOrbById));
    assert(!isSpiderOrb(&greenDashOrb));

    resetSimOrbTracking();
    recordSimOrbContact(&greenDashOrb, 5);
    recordSimOrbContact(&greenDashOrb, 7); // repeated broad-phase contact
    recordSimOrbContact(&ring, 9);
    assert(g_simOrbContactCount == 2);
    assert(g_simFirstOrbContactStep == 5);
    assert(g_simDashContactCount == 1);
    assert(g_simFirstDashContactStep == 5);
    assert(g_simRegularOrbContactCount == 1);
    assert(g_simFirstRegularOrbContactStep == 9);
    recordSimDashActivation(6);
    assert(g_simDashActivationCount == 1);
    assert(g_simFirstDashActivationStep == 6);
    resetSimOrbTracking();
    recordSimOrbContact(&spiderOrbById, 11);
    recordSimSpiderOrbContact(&spiderOrbById, 11, &ghostP1);
    recordSimSpiderOrbActivation(&spiderOrbById, 12);
    recordSimSpiderOrbActivation(&spiderOrbById, 13); // deduplicated
    assert(g_simSpiderOrbContactCount == 1);
    assert(g_simFirstSpiderOrbContactStep == 11);
    assert(g_simSpiderOrbActivationCount == 1);
    assert(g_simFirstSpiderOrbActivationStep == 12);
    assert(g_simOrbActivationCount == 1);
    resetSimOrbTracking();
    assert(g_simDashContactCount == 0 && g_simDashActivationCount == 0);
    assert(g_simSpiderOrbContactCount == 0 && g_simSpiderOrbActivationCount == 0);
    g_simDummies[0] = nullptr;
    g_simDummies[1] = nullptr;

    // Size portals must keep the clone running so Ship physics after a mini
    // transition can be evaluated; control-mode and linked portals still stop.
    GameObject miniPortal;
    miniPortal.m_objectID = 99;
    assert(isPortalId(miniPortal.m_objectID));
    assert(!requiresPortalResync(miniPortal.m_objectID));
    assert(isSimInteractable(&miniPortal));
    GameObject normalSizePortal;
    normalSizePortal.m_objectID = 101;
    assert(!requiresPortalResync(normalSizePortal.m_objectID));
    GameObject shipPortal;
    shipPortal.m_objectID = 13;
    assert(requiresPortalResync(shipPortal.m_objectID));

    // Orb planning must require a real activation and prefer survival. It
    // selects a delayed pulse when that pulse is materially safer than now.
    SimResult orbIdle;
    orbIdle.died = true;
    orbIdle.survived = 24;
    OrbTapCandidate orbCandidates[3];
    orbCandidates[0].delaySteps = 0;
    orbCandidates[0].result.died = true;
    orbCandidates[0].result.survived = 29;
    orbCandidates[0].result.orbActivations = 1;
    orbCandidates[1].delaySteps = 8;
    orbCandidates[1].result.died = false;
    orbCandidates[1].result.survived = 100;
    orbCandidates[1].result.orbActivations = 1;
    orbCandidates[2].delaySteps = 12;
    orbCandidates[2].result.died = false;
    orbCandidates[2].result.survived = 100;
    orbCandidates[2].result.orbContacts = 1; // contact without ringJump is not enough
    OrbTapPlan orbChoice = chooseOrbTapCandidate(orbIdle, orbCandidates, 3);
    assert(orbChoice.found && orbChoice.delaySteps == 8);
    assert(orbChoice.activations == 1);

    // If an immediate click is just as safe as a delayed click, avoid adding
    // unnecessary latency. The delayed choice is reserved for a real gain.
    OrbTapCandidate immediateTie[2];
    immediateTie[0].delaySteps = 0;
    immediateTie[0].result.died = false;
    immediateTie[0].result.survived = 100;
    immediateTie[0].result.orbActivations = 1;
    immediateTie[1].delaySteps = 8;
    immediateTie[1].result.died = false;
    immediateTie[1].result.survived = 100;
    immediateTie[1].result.orbActivations = 1;
    auto immediateChoice = chooseOrbTapCandidate(orbIdle, immediateTie, 2);
    assert(immediateChoice.found && immediateChoice.delaySteps == 0);

    // syncDummy must carry mini vehicle scale and collision dimensions across
    // a frame re-plan; otherwise the next Ship prediction uses normal bounds.
    PlayerObject miniSource, miniDummy;
    miniSource.m_vehicleSize = 0.5f;
    miniSource.m_width = 15.f;
    miniSource.m_height = 15.f;
    syncDummy(&miniDummy, &miniSource);
    assert(miniDummy.m_vehicleSize == 0.5f);
    assert(miniDummy.m_width == 15.f && miniDummy.m_height == 15.f);

    int scheduledOrbDelay = 8;
    assert(!advanceOrbTapSchedule(scheduledOrbDelay, 4));
    assert(scheduledOrbDelay == 4);
    assert(advanceOrbTapSchedule(scheduledOrbDelay, 4));
    SimResult orbWindowDeath;
    orbWindowDeath.died = true;
    orbWindowDeath.survived = 4;
    assert(orbTapScheduleStillReachable(orbWindowDeath, 4));
    orbWindowDeath.survived = 3;
    assert(!orbTapScheduleStillReachable(orbWindowDeath, 4));

    // Teleport orbs are known interaction boundaries (their linked destination
    // is not simulated), and a Tap must make a new edge if Jump is still held.
    GameObject teleportOrb;
    teleportOrb.m_objectType = GameObjectType::TeleportOrb;
    assert(isTeleportOrb(&teleportOrb));
    assert(requiresFreshPressEdge(BotAction::Tap, true));
    assert(!requiresFreshPressEdge(BotAction::Tap, false));
    assert(requiresFreshPressEdge(BotAction::TimedHold, true));
    assert(requiresFreshPressEdge(BotAction::DashTimedHold, true));
    assert(!requiresFreshPressEdge(BotAction::DashTimedHold, false));
    assert(!requiresFreshPressEdge(BotAction::Hold, true));

    // A two-switch wave plan must actually apply both input transitions.
    World world;
    PlayLayer layer;
    PlayerObject source, dummy;
    source.world = &world;
    dummy.world = &world;
    source.m_isDart = true;
    source.y = 120.f;
    SimRig rig;
    rig.pl = &layer;
    rig.source = &source;
    rig.dummy = &dummy;
    rig.dt = 0.25f;

    WavePlan sequence;
    sequence.startHolding = false;
    sequence.switchCount = 2;
    sequence.switchSteps[0] = 4;
    sequence.switchSteps[1] = 8;
    (void)runSimulation(rig, SimPlan::WavePattern, 0, -1, 12, 0, nullptr, kNoColor, &sequence);
    float sequencedY = dummy.y;

    (void)runSimulation(rig, SimPlan::Release, 0, -1, 12, 0, nullptr, kNoColor);
    float releasedY = dummy.y;
    assert(sequencedY > releasedY + 10.f);

    // Tap prediction must match the real controller's postUpdate release
    // cadence (4 physics substeps per rendered frame in this test).
    World groundWorld;
    PlayLayer groundLayer;
    PlayerObject cubeSource, cubeDummy;
    cubeSource.world = &groundWorld;
    cubeDummy.world = &groundWorld;
    cubeSource.m_isOnGround = true;
    cubeSource.x = 0.f;
    cubeSource.y = 0.f;
    SimRig tapRig;
    tapRig.pl = &groundLayer;
    tapRig.source = &cubeSource;
    tapRig.dummy = &cubeDummy;
    tapRig.dt = 0.25f;
    g_frameSubsteps = 4;
    (void)runSimulation(tapRig, SimPlan::Tap, 0, -1, 12, 0, nullptr, kNoColor);
    assert(cubeDummy.heldUpdates == 4);

    // Airborne orb taps must also release after one frame; they must not wait
    // for a grounded transition that may not occur for many frames.
    PlayerObject airSource, airDummy;
    airSource.world = &groundWorld;
    airDummy.world = &groundWorld;
    airSource.m_isOnGround = false;
    airSource.y = 80.f;
    SimRig airRig;
    airRig.pl = &groundLayer;
    airRig.source = &airSource;
    airRig.dummy = &airDummy;
    airRig.dt = 0.25f;
    (void)runSimulation(airRig, SimPlan::Tap, 0, -1, 12, 0, nullptr, kNoColor);
    assert(airDummy.heldUpdates == 4);

    int tapRemaining = 4;
    assert(advanceTapPulse(tapRemaining, 4));
    assert(tapRemaining == 0);
    tapRemaining = 8;
    assert(!advanceTapPulse(tapRemaining, 4));
    assert(advanceTapPulse(tapRemaining, 4));

    // Regression: if Tap-now and a later Tap both survive, Cube must commit
    // to the currently validated jump rather than release forever while the
    // same future window keeps moving forward one frame at a time.
    World cubeSpikeWorld;
    cubeSpikeWorld.spikes = {{35.f}};
    PlayerObject cubePlannerSource, cubePlannerDummy;
    cubePlannerSource.world = &cubeSpikeWorld;
    cubePlannerDummy.world = &cubeSpikeWorld;
    cubePlannerSource.m_isOnGround = true;
    cubePlannerSource.x = 0.f;
    cubePlannerSource.y = 0.f;
    SimRig cubePlannerRig;
    cubePlannerRig.pl = &groundLayer;
    cubePlannerRig.source = &cubePlannerSource;
    cubePlannerRig.dummy = &cubePlannerDummy;
    cubePlannerRig.dt = 0.25f;
    SimResult cubeIdle = runSimulation(
        cubePlannerRig, SimPlan::Release, 0, -1, 100, 0, nullptr, kNoColor
    );
    SimResult cubeTapNow = probe(cubePlannerRig, SimPlan::Tap, 0, -1, 100);
    SimResult cubeTapLater = probe(cubePlannerRig, SimPlan::Tap, 6, -1, 100);
    assert(cubeIdle.died && !cubeTapNow.died && !cubeTapLater.died);
    assert(decideGround(cubePlannerRig, cubeIdle, 100) == BotAction::Tap);

    // When Tap-now is too early but a delayed tap is viable, Cube should wait;
    // after one real frame of forward motion, the same obstacle must become an
    // immediate Tap rather than causing a repeated defer.
    World cubeTimingWorld;
    cubeTimingWorld.spikes = {{110.f}};
    PlayerObject cubeTimingSource, cubeTimingDummy;
    cubeTimingSource.world = &cubeTimingWorld;
    cubeTimingDummy.world = &cubeTimingWorld;
    cubeTimingSource.m_isOnGround = true;
    SimRig cubeTimingRig;
    cubeTimingRig.pl = &groundLayer;
    cubeTimingRig.source = &cubeTimingSource;
    cubeTimingRig.dummy = &cubeTimingDummy;
    cubeTimingRig.dt = 0.25f;
    SimResult cubeTimingIdle = runSimulation(
        cubeTimingRig, SimPlan::Release, 0, -1, 180, 0, nullptr, kNoColor
    );
    SimResult cubeTooEarly = probe(cubeTimingRig, SimPlan::Tap, 0, -1, 180);
    SimResult cubeLaterWorks = probe(cubeTimingRig, SimPlan::Tap, 6, -1, 180);
    assert(cubeTimingIdle.died && cubeTooEarly.died && !cubeLaterWorks.died);
    assert(decideGround(cubeTimingRig, cubeTimingIdle, 180) == BotAction::Release);
    for (int i = 0; i < 4; ++i) {
        cubeTimingSource.releaseButton(PlayerButton::Jump);
        cubeTimingSource.update(0.25f);
        groundLayer.checkCollisions(&cubeTimingSource, 0.25f, false);
    }
    cubeTimingIdle = runSimulation(
        cubeTimingRig, SimPlan::Release, 0, -1, 180, 0, nullptr, kNoColor
    );
    assert(decideGround(cubeTimingRig, cubeTimingIdle, 180) == BotAction::Tap);

    // Robot uses the same current-first rule but keeps a finite hold, so a
    // safe immediate jump is not postponed just because a later jump also works.
    cubePlannerSource.m_isRobot = true;
    int robotSelectedHold = 0;
    assert(decideRobot(cubePlannerRig, cubeIdle, 100, &robotSelectedHold) == BotAction::TimedHold);
    assert(robotSelectedHold == 4);
    cubePlannerSource.m_isRobot = false;

    // Ball also commits to an immediately safe gravity flip instead of
    // repeatedly deferring it because a later flip would survive too.
    World ballSpikeWorld;
    ballSpikeWorld.spikes = {{35.f}};
    PlayerObject ballPlannerSource, ballPlannerDummy;
    ballPlannerSource.world = &ballSpikeWorld;
    ballPlannerDummy.world = &ballSpikeWorld;
    ballPlannerSource.m_isBall = true;
    ballPlannerSource.m_isOnGround = false;
    ballPlannerSource.x = 0.f;
    ballPlannerSource.y = 15.f;
    SimRig ballPlannerRig;
    ballPlannerRig.pl = &groundLayer;
    ballPlannerRig.source = &ballPlannerSource;
    ballPlannerRig.dummy = &ballPlannerDummy;
    ballPlannerRig.dt = 0.25f;
    SimResult ballIdle = runSimulation(
        ballPlannerRig, SimPlan::Release, 0, -1, 100, 0, nullptr, kNoColor
    );
    SimResult ballFlipNow = probe(ballPlannerRig, SimPlan::Tap, 0, -1, 100);
    SimResult ballFlipLater = probe(ballPlannerRig, SimPlan::Tap, 4, -1, 100);
    assert(ballIdle.died && !ballFlipNow.died && !ballFlipLater.died);
    assert(decideBall(ballPlannerRig, ballIdle, 100) == BotAction::Tap);

    // Ball uses a pulse edge, not a held jump. The toy model flips gravity once
    // on the rising edge and must not flip again while the same pulse is down.
    PlayerObject ballSource, ballDummy;
    ballSource.world = &groundWorld;
    ballDummy.world = &groundWorld;
    ballSource.m_isBall = true;
    ballSource.m_isOnGround = false;
    ballSource.y = 80.f;
    SimRig ballRig;
    ballRig.pl = &groundLayer;
    ballRig.source = &ballSource;
    ballRig.dummy = &ballDummy;
    ballRig.dt = 0.25f;
    (void)runSimulation(ballRig, SimPlan::Tap, 0, -1, 8, 0, nullptr, kNoColor);
    assert(ballDummy.heldUpdates == 4);
    assert(ballDummy.m_isUpsideDown != ballSource.m_isUpsideDown);

    // Timed robot holds release exactly at the requested substep count, which
    // allows repeated high jumps instead of one unbounded hold.
    PlayerObject robotSource, robotDummy;
    robotSource.world = &groundWorld;
    robotDummy.world = &groundWorld;
    robotSource.m_isOnGround = true;
    robotSource.m_isRobot = true;
    robotSource.x = 0.f;
    robotSource.y = 0.f;
    SimRig robotRig;
    robotRig.pl = &groundLayer;
    robotRig.source = &robotSource;
    robotRig.dummy = &robotDummy;
    robotRig.dt = 0.25f;
    (void)runSimulation(robotRig, SimPlan::Hold, 0, 8, 12, 0, nullptr, kNoColor);
    assert(robotDummy.heldUpdates == 8);

    std::puts("ordinary orb + Dash Orb classification/tracking, activation counters, immediate-vs-delayed orb choice, scheduled click countdown, mini-size clone-state continuation, one-frame tap release, Cube/Robot/Ball regressions, teleport boundary and Wave plan: ok");
    return 0;
}

