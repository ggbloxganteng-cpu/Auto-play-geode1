#include "../src/core/performance/AdaptiveScheduler.hpp"
#include "../src/core/performance/IncrementalWork.hpp"
#include "../src/core/performance/StaticFingerprintCache.hpp"

#include <cassert>
#include <chrono>
#include <cstddef>
#include <iostream>

using namespace at::performance;

int main() {
    using Clock = AdaptiveScheduler::Clock;
    auto now = Clock::now();

    auto low = Settings::forPreset(Preset::UltraLow);
    assert(low.frameBudgetUs == 250);
    assert(low.waveCandidates == 2);
    assert(low.objectsPerSlice == 3);

    AdaptiveScheduler scheduler(low);
    scheduler.beginFrame(16.0f, now);
    scheduler.notifyJump(now);
    assert(scheduler.mayRun(AdaptiveScheduler::WorkClass::GameplayCritical, now));
    assert(scheduler.mayRun(AdaptiveScheduler::WorkClass::CachedTrajectory, now));
    assert(!scheduler.mayRun(AdaptiveScheduler::WorkClass::LevelScan, now));

    auto afterGrace = now + std::chrono::milliseconds(low.jumpGraceMs + 1);
    scheduler.beginFrame(16.0f, afterGrace);
    assert(scheduler.mayRun(AdaptiveScheduler::WorkClass::LevelScan, afterGrace));

    scheduler.notifySevereFrameHitch();
    assert(!scheduler.mayRun(AdaptiveScheduler::WorkClass::GlobalPlan, afterGrace));
    assert(scheduler.mayRun(AdaptiveScheduler::WorkClass::GameplayCritical, afterGrace));

    Settings custom = Settings::forPreset(Preset::Custom);
    custom.frameBudgetUs = 999999;
    custom.objectsPerSlice = 999;
    custom.sanitize();
    assert(custom.frameBudgetUs == 2500);
    assert(custom.objectsPerSlice == 32);

    AdaptiveScheduler incremental(Settings::forPreset(Preset::High));
    auto later = Clock::now() + std::chrono::milliseconds(1);
    incremental.beginFrame(12.0f, later);
    std::size_t remaining = 7;
    const auto done = runIncrementalSlice(
        incremental,
        AdaptiveScheduler::WorkClass::GlobalPlan,
        4,
        [&remaining]() { if (remaining == 0) return false; --remaining; return true; });
    assert(done <= 4);
    assert(remaining == 7 - done);

    StaticFingerprintCache<4> cache;
    assert(!cache.unchanged(101, 0xAA));
    assert(cache.unchanged(101, 0xAA));
    assert(!cache.unchanged(101, 0xAB));
    assert(!cache.unchanged(202, 0xBB));
    assert(cache.size() == 2);
    cache.clear();
    assert(cache.size() == 0);

    AdaptiveScheduler hitch(Settings::forPreset(Preset::Low));
    auto hitchTime = Clock::now();
    hitch.beginFrame(48.0f, hitchTime);
    assert(!hitch.mayRun(AdaptiveScheduler::WorkClass::WaveDeep, hitchTime));
    assert(hitch.mayRun(AdaptiveScheduler::WorkClass::GameplayCritical, hitchTime));

    const auto metrics = scheduler.metrics(afterGrace);
    assert(metrics.emergencyYields == 1);
    std::cout << "performance core tests: ok\n";
    return 0;
}
